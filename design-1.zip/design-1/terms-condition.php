<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>

</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-4" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>We have all the answers for your queries!</h1> </div>
            </div>
        </div>
    </div>
</section>

       <?php include'vip/number-tag.php';?>

 <section class="section" id="faqs">
  <div class="container font">
    <div class="col-md-10 col-lg-offset-1">
      <div class="margin-bottom20">
        <h2 class="text-gray">Refund Policy</h2>
        <ul>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> Refund policy applies to translation projects within 15 days commencing from delivery date </li>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> Should the client return the work after 15 days for quality issues, the client shall incur a 30% charge for proofreading and 50% for rework. (The 30% & 50% is calculated based on the file length and/or page count). </li>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> This refund policy is limited only for category A (Excellent) and B (Good) quality audio/document. </li>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> We reserve the right to conduct a proofreading review, to determine the validity of a quality issue before processing a refund. </li>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> The request shall be honored if the results of the proofreading review is able to validate a failure
            <in our stated quality standards and guidelines. A revised copy shall be requested from the client. </li>
              <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> We do not guarantee 98% accuracy for Rush orders and poor quality audio or poorly- written documents. We also reserve the right to refuse rework requests for these poor conditions. </li>
        </ul>
        <h2 class="text-gray">Transcription Service</h2>
        <ul>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> This refund policy is not applicable for poor quality files and Rush orders. </li>
        </ul>
        <h2 class="text-gray">Translation Service</h2>
        <ul>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> This refund policy is not applicable for poor quality audio or poorly- written documents from clients and Rush orders </li>
        </ul>
        <h2 class="text-gray">Captioning & Subtitling Service</h2>
        <ul>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> This refund policy is not applicable for poor quality video files and Rush orders.</li>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> We will no longer honor a refund request once the client approves the delivered Transcripts/Translation before the Captioning/Subtitling is made. </li>
          </li>
        </ul>
        <h2 class="text-gray">Typing (Document)</h2>
        <ul>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> This refund policy is not applicable for hand written documents/ poor legibility or print quality of documents and Rush orders</li>
          </li>
        </ul>
        <h2 class="text-gray">For Voiceover</h2>
        <ul>
          <li class="vd-para"><span class="mp-terms"><i class="fa fa-check-square" aria-hidden="true"></i></span> This refund policy is not applicable for Rush orders and voices approved by the client before performing the work.</li>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>


<section class="vd-black">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                </div>
            </div>
            <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
            </div>
        </div>
    </div>
</section>





 <?php include'vip/testimonial-tag.php';?>


 <?php include'vip/client-tag.php';?>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

    </body>
</html>
