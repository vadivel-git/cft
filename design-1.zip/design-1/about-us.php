<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>

</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-2" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>About Us</h1> </div>
            </div>
        </div>
    </div>
</section>

       <?php include'vip/number-tag.php';?>

<section class="section" id="features">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="tabbable-panel margin-tops4 ">
                    <div class="tabbable-line">
                        <ul class="nav nav-tabs tabtop  tabsetting">
                            <li class="active"> <a href="#tab_default_1" data-toggle="tab">Who we are</a> </li>
                            <li> <a href="#tab_default_2" data-toggle="tab">Our Services & Rates</a> </li>
                            <li> <a href="#tab_default_3" data-toggle="tab">Benefits we provide</a> </li>
                        </ul>
                        <div class="tab-content margin-tops">
                            <div class="tab-pane active fade in" id="tab_default_1">
                                <p class="text-muted vd-para">We have earned the reputation as a reliable company with our focus on excellence in our services and our treatment to our clients as our most valued asset. We always leave our customer satisfied by striving for perfection in our work. We encourage cooperation in our workforce and don’t leave anyone behind. Our tools and techniques are always updated with the latest trends in the market.</p>

                            </div>
                            <div class="tab-pane fade" id="tab_default_2">
                                <p class="text-muted vd-para vd-list">The product of our services can be used as a useful tool for our clients that will be beneficial to promote their personal or business interests. With modern technology and our professionals, our rates are considered a bargain that is unmatched in the industry.</p>
                            </div>
                            <div class="tab-pane fade" id="tab_default_3">
                                <p class="text-muted vd-para vd-list">Not all companies are ISO 9001:2008 certified. The companies have to pass stringent standards of quality, and we are proud to be one. Ordering is simple, we support all file formats, and provide 100% security and confidentiality. A project can be completed within 24 hours, in the case of a tight deadline avail of our rush and super rush services. Our live customer support operates on a 24/7/365 work schedule, they never sleep, to provide a pleasant experience with accurate answers to your inquiries.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 margin-tops4">
                <img src="img/showcase.jpg" alt="about us" class="img-responsive">
            </div>
        </div>
    </div>
    </div>
</section>



<section class="vd-black">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                </div>
            </div>
            <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
            </div>
        </div>
    </div>
</section>





 <?php include'vip/testimonial-tag.php';?>


 <?php include'vip/client-tag.php';?>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

    </body>
</html>
