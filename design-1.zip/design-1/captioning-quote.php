<?php include'vip/doctype.php';?>
  <title>Online Services</title>
  <meta name="description" content="Responsive bootstrap landing template">
  <meta name="author" content="Coderthemes">
  <?php include'vip/link-css.php';?>
    <link rel="stylesheet" href="css/select.css"> </head>

    <body>
      <?php include'vip/header.php';?>
        <section class="section-lg home-alt bg-img-4" id="home">
          <div class="bg-overlay1"></div>
          <div class="container">
            <div class="row">
              <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                  <h1>We have all the answers for your queries!</h1> </div>
              </div>
            </div>
          </div>
        </section>
        <?php include'vip/number-tag.php';?>
          <section class="section" id="faqs">
            <div class="container">
              <div class="col-xs-12 col-sm-10 col-lg-8 col-sm-offset-1 col-lg-offset-2">
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group">
                      <input type="text" placeholder="Full Name*" class="form-control" id="name" data-placement="bottom"> </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group">
                      <input type="text" placeholder="Email Id*" class="form-control" id="email" data-placement="bottom"> </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group ">
                      <select class="plain-select select2_group form-control" id="qcountrys" data-placement="bottom">
                        <option value="">Select Country*</option>
                        <option value="United States">United States</option>
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="American Samoa">American Samoa</option>
                        <option value="Andorra">Andorra</option>
                        <option value="Angola">Angola</option>
                        <option value="Anguilla">Anguilla</option>
                        <option value="Antarctica">Antarctica</option>
                        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Armenia">Armenia</option>
                        <option value="Aruba">Aruba</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Azerbaijan">Azerbaijan</option>
                        <option value="Bahamas">Bahamas</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Barbados">Barbados</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Belize">Belize</option>
                        <option value="Benin">Benin</option>
                        <option value="Bermuda">Bermuda</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Bolivia">Bolivia</option>
                        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                        <option value="Botswana">Botswana</option>
                        <option value="Brazil">Brazil</option>
                        <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                        <option value="British Virgin Islands">British Virgin Islands</option>
                        <option value="Brunei">Brunei</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Burkina Faso">Burkina Faso</option>
                        <option value="Burma (Myanmar)">Burma (Myanmar)</option>
                        <option value="Burundi">Burundi</option>
                        <option value="Cambodia">Cambodia</option>
                        <option value="Cameroon">Cameroon</option>
                        <option value="Canada">Canada</option>
                        <option value="Cape Verde">Cape Verde</option>
                        <option value="Cayman Islands">Cayman Islands</option>
                        <option value="Central African Republic">Central African Republic</option>
                        <option value="Chad">Chad</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="Christmas Island">Christmas Island</option>
                        <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Comoros">Comoros</option>
                        <option value="Cook Islands">Cook Islands</option>
                        <option value="Costa Rica">Costa Rica</option>
                        <option value="Croatia">Croatia</option>
                        <option value="Cuba">Cuba</option>
                        <option value="Cyprus">Cyprus</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Djibouti">Djibouti</option>
                        <option value="Dominica">Dominica</option>
                        <option value="Dominican Republic">Dominican Republic</option>
                        <option value="Ecuador">Ecuador</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Ethiopia">Ethiopia</option>
                        <option value="Falkland Islands">Falkland Islands</option>
                        <option value="Faroe Islands">Faroe Islands</option>
                        <option value="Fiji">Fiji</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="French Polynesia">French Polynesia</option>
                        <option value="Gabon">Gabon</option>
                        <option value="Gambia">Gambia</option>
                        <option value="Gaza Strip">Gaza Strip</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Gibraltar">Gibraltar</option>
                        <option value="Greece">Greece</option>
                        <option value="Greenland">Greenland</option>
                        <option value="Grenada">Grenada</option>
                        <option value="Guam">Guam</option>
                        <option value="Guatemala">Guatemala</option>
                        <option value="Guinea">Guinea</option>
                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                        <option value="Guyana">Guyana</option>
                        <option value="Haiti">Haiti</option>
                        <option value="Holy See (Vatican City)">Holy See (Vatican City)</option>
                        <option value="Honduras">Honduras</option>
                        <option value="Hong Kong">Hong Kong</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Iceland">Iceland</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Iran">Iran</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Isle of Man">Isle of Man</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Ivory Coast">Ivory Coast</option>
                        <option value="Jamaica">Jamaica</option>
                        <option value="Japan">Japan</option>
                        <option value="Jersey">Jersey</option>
                        <option value="Jordan">Jordan</option>
                        <option value="Kazakhstan">Kazakhstan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Kiribati">Kiribati</option>
                        <option value="Kosovo">Kosovo</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                        <option value="Laos">Laos</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lebanon">Lebanon</option>
                        <option value="Lesotho">Lesotho</option>
                        <option value="Liberia">Liberia</option>
                        <option value="Libya">Libya</option>
                        <option value="Liechtenstein">Liechtenstein</option>
                        <option value="Lithuania">Lithuania</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Macau">Macau</option>
                        <option value="Macedonia">Macedonia</option>
                        <option value="Madagascar">Madagascar</option>
                        <option value="Malawi">Malawi</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Maldives">Maldives</option>
                        <option value="Mali">Mali</option>
                        <option value="Malta">Malta</option>
                        <option value="Marshall Islands">Marshall Islands</option>
                        <option value="Mauritania">Mauritania</option>
                        <option value="Mauritius">Mauritius</option>
                        <option value="Mayotte">Mayotte</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Micronesia">Micronesia</option>
                        <option value="Moldova">Moldova</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Mongolia">Mongolia</option>
                        <option value="Montenegro">Montenegro</option>
                        <option value="Montserrat">Montserrat</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Mozambique">Mozambique</option>
                        <option value="Namibia">Namibia</option>
                        <option value="Nauru">Nauru</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="Netherlands Antilles">Netherlands Antilles</option>
                        <option value="New Caledonia">New Caledonia</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nicaragua">Nicaragua</option>
                        <option value="Niger">Niger</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="Niue">Niue</option>
                        <option value="Norfolk Island">Norfolk Island</option>
                        <option value="North Korea">North Korea</option>
                        <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                        <option value="Norway">Norway</option>
                        <option value="Oman">Oman</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Palau">Palau</option>
                        <option value="Panama">Panama</option>
                        <option value="Papua New Guinea">Papua New Guinea</option>
                        <option value="Paraguay">Paraguay</option>
                        <option value="Peru">Peru</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Pitcairn Islands">Pitcairn Islands</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Puerto Rico">Puerto Rico</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Republic of the Congo">Republic of the Congo</option>
                        <option value="Romania">Romania</option>
                        <option value="Russia">Russia</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="Saint Barthelemy">Saint Barthelemy</option>
                        <option value="Saint Helena">Saint Helena</option>
                        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                        <option value="Saint Lucia">Saint Lucia</option>
                        <option value="Saint Martin">Saint Martin</option>
                        <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                        <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                        <option value="Samoa">Samoa</option>
                        <option value="San Marino">San Marino</option>
                        <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Senegal">Senegal</option>
                        <option value="Serbia">Serbia</option>
                        <option value="Seychelles">Seychelles</option>
                        <option value="Sierra Leone">Sierra Leone</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Slovakia">Slovakia</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Solomon Islands">Solomon Islands</option>
                        <option value="Somalia">Somalia</option>
                        <option value="South Africa">South Africa</option>
                        <option value="South Korea">South Korea</option>
                        <option value="Spain">Spain</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Sudan">Sudan</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Svalbard">Svalbard</option>
                        <option value="Swaziland">Swaziland</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Syria">Syria</option>
                        <option value="Taiwan">Taiwan</option>
                        <option value="Tajikistan">Tajikistan</option>
                        <option value="Tanzania">Tanzania</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Timor-Leste">Timor-Leste</option>
                        <option value="Togo">Togo</option>
                        <option value="Tokelau">Tokelau</option>
                        <option value="Tonga">Tonga</option>
                        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                        <option value="Tunisia">Tunisia</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Turkmenistan">Turkmenistan</option>
                        <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                        <option value="Tuvalu">Tuvalu</option>
                        <option value="Uganda">Uganda</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Uruguay">Uruguay</option>
                        <option value="US Virgin Islands">US Virgin Islands</option>
                        <option value="Uzbekistan">Uzbekistan</option>
                        <option value="Vanuatu">Vanuatu</option>
                        <option value="Venezuela">Venezuela</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="Wallis and Futuna">Wallis and Futuna</option>
                        <option value="West Bank">West Bank</option>
                        <option value="Western Sahara">Western Sahara</option>
                        <option value="Yemen">Yemen</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-2 col-md-2 mp-pt10">
                    <div class="form-group">
                      <input type="text" placeholder="Area Code" class="form-control" id="qacode" data-placement="bottom"> </div>
                  </div>
                  <div class="col-xs-12 col-sm-4 col-md-4 mp-pt10">
                    <div class="form-group">
                      <input type="text" placeholder="Phone Number" class="form-control" id="qphone" data-placement="bottom"> </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group plain-select">
                      <select multiple="multiple" class="select2 form-control" id="language" data-placement="bottom">
                        <option hidden="">Target language</option>
                        <option value="Abkhazian">Abkhazian</option>
                        <option value="Acehnese">Acehnese</option>
                        <option value="Acholi">Acholi</option>
                        <option value="Adyghe">Adyghe</option>
                        <option value="Afar">Afar</option>
                        <option value="Afrikaans">Afrikaans</option>
                        <option value="Akan">Akan</option>
                        <option value="Albanian">Albanian</option>
                        <option value="Alemannic">Alemannic</option>
                        <option value="Amharic">Amharic</option>
                        <option value="Anglo-Saxon">Anglo-Saxon</option>
                        <option value="Arabic">Arabic</option>
                        <option value="Aragonese">Aragonese</option>
                        <option value="Aramaic">Aramaic</option>
                        <option value="Armenian">Armenian</option>
                        <option value="Aromanian">Aromanian</option>
                        <option value="Ashanti">Ashanti</option>
                        <option value="Assamese">Assamese</option>
                        <option value="Assyrian">Assyrian</option>
                        <option value="Asturian">Asturian</option>
                        <option value="Avar">Avar</option>
                        <option value="Aymara">Aymara</option>
                        <option value="Azerbaijani">Azerbaijani</option>
                        <option value="Bahasa">Bahasa</option>
                        <option value="Bambara">Bambara</option>
                        <option value="Banjar">Banjar</option>
                        <option value="Banyumasan">Banyumasan</option>
                        <option value="Bashkir">Bashkir</option>
                        <option value="Basque">Basque</option>
                        <option value="Bavarian">Bavarian</option>
                        <option value="Belarusian">Belarusian</option>
                        <option value="Belarusian (Taraškievica)">Belarusian (Taraškievica)</option>
                        <option value="Bengali">Bengali</option>
                        <option value="Bhutani">Bhutani</option>
                        <option value="Bihari">Bihari</option>
                        <option value="Bishnupriya Manipuri">Bishnupriya Manipuri</option>
                        <option value="Bislama">Bislama</option>
                        <option value="Bosnian">Bosnian</option>
                        <option value="Breton">Breton</option>
                        <option value="Buginese">Buginese</option>
                        <option value="Bulgarian">Bulgarian</option>
                        <option value="Burmese">Burmese</option>
                        <option value="Buryat">Buryat</option>
                        <option value="Byelorussian">Byelorussian</option>
                        <option value="Cambodian">Cambodian</option>
                        <option value="Cantonese">Cantonese</option>
                        <option value="Cape">Cape</option>
                        <option value="Catalan">Catalan</option>
                        <option value="Cebuano">Cebuano</option>
                        <option value="Central Bicolano">Central Bicolano</option>
                        <option value="Chamorro">Chamorro</option>
                        <option value="Chavacano">Chavacano</option>
                        <option value="Chechen">Chechen</option>
                        <option value="Cherokee">Cherokee</option>
                        <option value="Chewa">Chewa</option>
                        <option value="Cheyenne">Cheyenne</option>
                        <option value="Chichewa">Chichewa</option>
                        <option value="Chinese">Chinese</option>
                        <option value="Chinese Simplified">Chinese Simplified</option>
                        <option value="Chinese Traditional">Chinese Traditional</option>
                        <option value="Choctaw">Choctaw</option>
                        <option value="Chuukese">Chuukese</option>
                        <option value="Chuvash">Chuvash</option>
                        <option value="Classical Chinese">Classical Chinese</option>
                        <option value="Cornish">Cornish</option>
                        <option value="Corsican">Corsican</option>
                        <option value="Cree">Cree</option>
                        <option value="Crimean Tatar">Crimean Tatar</option>
                        <option value="Croatian">Croatian</option>
                        <option value="Czech">Czech</option>
                        <option value="Danish">Danish</option>
                        <option value="Dari">Dari</option>
                        <option value="Dinka">Dinka</option>
                        <option value="Divehi">Divehi</option>
                        <option value="Dutch">Dutch</option>
                        <option value="Dutch Low Saxon">Dutch Low Saxon</option>
                        <option value="Dzongkha">Dzongkha</option>
                        <option value="Edo">Edo</option>
                        <option value="Efik">Efik</option>
                        <option value="Egyptian Arabic">Egyptian Arabic</option>
                        <option value="Emilian-Romagnol">Emilian-Romagnol</option>
                        <option value="English">English</option>
                        <option value="Erzya">Erzya</option>
                        <option value="Esperanto">Esperanto</option>
                        <option value="Estonian">Estonian</option>
                        <option value="Ethiopian">Ethiopian</option>
                        <option value="Ewe">Ewe</option>
                        <option value="Extremaduran">Extremaduran</option>
                        <option value="Faeroese">Faeroese</option>
                        <option value="Farsi">Farsi</option>
                        <option value="Fiji">Fiji</option>
                        <option value="Fiji Hindi">Fiji Hindi</option>
                        <option value="Fijian">Fijian</option>
                        <option value="Finnish">Finnish</option>
                        <option value="Flemish">Flemish</option>
                        <option value="Franco-Provençal">Franco-Provençal</option>
                        <option value="French">French</option>
                        <option value="Frisian">Frisian</option>
                        <option value="Friulian">Friulian</option>
                        <option value="Fula">Fula</option>
                        <option value="Fulani">Fulani</option>
                        <option value="Fulfulde">Fulfulde</option>
                        <option value="Ga">Ga</option>
                        <option value="Gaelic">Gaelic</option>
                        <option value="Gaelic Manx">Gaelic Manx</option>
                        <option value="Gaelic Scot">Gaelic Scot</option>
                        <option value="Gagauz">Gagauz</option>
                        <option value="Galician">Galician</option>
                        <option value="Gan">Gan</option>
                        <option value="Georgian">Georgian</option>
                        <option value="German">German</option>
                        <option value="Gilaki">Gilaki</option>
                        <option value="Goan Konkani">Goan Konkani</option>
                        <option value="Gothic">Gothic</option>
                        <option value="Greek">Greek</option>
                        <option value="Greenlandic">Greenlandic</option>
                        <option value="Guarani">Guarani</option>
                        <option value="Gujarati">Gujarati</option>
                        <option value="Haitian">Haitian</option>
                        <option value="Hakka">Hakka</option>
                        <option value="Hausa">Hausa</option>
                        <option value="Hawaiian">Hawaiian</option>
                        <option value="Hebrew">Hebrew</option>
                        <option value="Herero">Herero</option>
                        <option value="Hill Mari">Hill Mari</option>
                        <option value="Hindi">Hindi</option>
                        <option value="Hiri Motu">Hiri Motu</option>
                        <option value="Hmong">Hmong</option>
                        <option value="Ho">Ho</option>
                        <option value="Hungarian">Hungarian</option>
                        <option value="Ibibio">Ibibio</option>
                        <option value="Icelandic">Icelandic</option>
                        <option value="Ido">Ido</option>
                        <option value="Igbo">Igbo</option>
                        <option value="Ilocano">Ilocano</option>
                        <option value="Indonesian">Indonesian</option>
                        <option value="Interlingua">Interlingua</option>
                        <option value="Interlingue">Interlingue</option>
                        <option value="Inuktitut">Inuktitut</option>
                        <option value="Inupiak">Inupiak</option>
                        <option value="Irish">Irish</option>
                        <option value="Italian">Italian</option>
                        <option value="Jamaican Patois">Jamaican Patois</option>
                        <option value="Japanese">Japanese</option>
                        <option value="Javanese">Javanese</option>
                        <option value="Kabardian">Kabardian</option>
                        <option value="Kabyle">Kabyle</option>
                        <option value="Kalmyk">Kalmyk</option>
                        <option value="Kanjobal">Kanjobal</option>
                        <option value="Kannada">Kannada</option>
                        <option value="Kanuri">Kanuri</option>
                        <option value="Kapampangan">Kapampangan</option>
                        <option value="Karachay-Balkar">Karachay-Balkar</option>
                        <option value="Karakalpak">Karakalpak</option>
                        <option value="Karen">Karen</option>
                        <option value="Kashmiri">Kashmiri</option>
                        <option value="Kashubian">Kashubian</option>
                        <option value="Kazakh">Kazakh</option>
                        <option value="Khmer">Khmer</option>
                        <option value="Kikuyu">Kikuyu</option>
                        <option value="Kinyarwanda">Kinyarwanda</option>
                        <option value="Kirghiz">Kirghiz</option>
                        <option value="Kirundi">Kirundi</option>
                        <option value="Komi">Komi</option>
                        <option value="Komi-Permyak">Komi-Permyak</option>
                        <option value="konkani">konkani</option>
                        <option value="Korean">Korean</option>
                        <option value="Kuanyama">Kuanyama</option>
                        <option value="Kurdish">Kurdish</option>
                        <option value="Kurdish (Kurmanji)">Kurdish (Kurmanji)</option>
                        <option value="Kurdish (Sorani)">Kurdish (Sorani)</option>
                        <option value="Ladino">Ladino</option>
                        <option value="Lak">Lak</option>
                        <option value="Lao">Lao</option>
                        <option value="Laotian">Laotian</option>
                        <option value="Latgalian">Latgalian</option>
                        <option value="Latin">Latin</option>
                        <option value="Latvian">Latvian</option>
                        <option value="Lebanese">Lebanese</option>
                        <option value="Lezgian">Lezgian</option>
                        <option value="Ligurian">Ligurian</option>
                        <option value="Limburgish">Limburgish</option>
                        <option value="Lingala">Lingala</option>
                        <option value="Lithuanian">Lithuanian</option>
                        <option value="Lojban">Lojban</option>
                        <option value="Lombard">Lombard</option>
                        <option value="Low Saxon">Low Saxon</option>
                        <option value="Lower Sorbian">Lower Sorbian</option>
                        <option value="Luganda">Luganda</option>
                        <option value="Luxembourgish">Luxembourgish</option>
                        <option value="Macedonian">Macedonian</option>
                        <option value="Maithili">Maithili</option>
                        <option value="Malagasy">Malagasy</option>
                        <option value="Malay">Malay</option>
                        <option value="Malayalam">Malayalam</option>
                        <option value="Maltese">Maltese</option>
                        <option value="Mam">Mam</option>
                        <option value="Mandarin">Mandarin</option>
                        <option value="Mandingo">Mandingo</option>
                        <option value="Mandinka">Mandinka</option>
                        <option value="Manx">Manx</option>
                        <option value="Maori">Maori</option>
                        <option value="Marathi">Marathi</option>
                        <option value="Marshallese">Marshallese</option>
                        <option value="Mazandarani">Mazandarani</option>
                        <option value="Meadow Mari">Meadow Mari</option>
                        <option value="Mien">Mien</option>
                        <option value="Min Dong">Min Dong</option>
                        <option value="Min Nan">Min Nan</option>
                        <option value="Mina">Mina</option>
                        <option value="Minangkabau">Minangkabau</option>
                        <option value="Mingrelian">Mingrelian</option>
                        <option value="Mirandese">Mirandese</option>
                        <option value="Moksha">Moksha</option>
                        <option value="Moldovan">Moldovan</option>
                        <option value="Mongolian">Mongolian</option>
                        <option value="Moroccan">Moroccan</option>
                        <option value="Muscogee">Muscogee</option>
                        <option value="Nahuatl">Nahuatl</option>
                        <option value="Nauruan">Nauruan</option>
                        <option value="Navajo">Navajo</option>
                        <option value="Ndonga">Ndonga</option>
                        <option value="Neapolitan">Neapolitan</option>
                        <option value="Nepali">Nepali</option>
                        <option value="Newar">Newar</option>
                        <option value="Norfolk">Norfolk</option>
                        <option value="Norman">Norman</option>
                        <option value="North Frisian">North Frisian</option>
                        <option value="Northern Luri">Northern Luri</option>
                        <option value="Northern Sami">Northern Sami</option>
                        <option value="Northern Sotho">Northern Sotho</option>
                        <option value="Norwegian">Norwegian</option>
                        <option value="Norwegian ">Norwegian </option>
                        <option value="Novial">Novial</option>
                        <option value="Nuer">Nuer</option>
                        <option value="Nuosu">Nuosu</option>
                        <option value="Occitan">Occitan</option>
                        <option value="Old Church Slavonic">Old Church Slavonic</option>
                        <option value="Oriya/Odia">Oriya/Odia</option>
                        <option value="Oromo">Oromo</option>
                        <option value="Ossetian">Ossetian</option>
                        <option value="Palatinate German">Palatinate German</option>
                        <option value="Pali">Pali</option>
                        <option value="Pangasinan">Pangasinan</option>
                        <option value="Papiamento">Papiamento</option>
                        <option value="Papiamentu">Papiamentu</option>
                        <option value="Paraguayan">Paraguayan</option>
                        <option value="Pashto">Pashto</option>
                        <option value="Pennsylvania German">Pennsylvania German</option>
                        <option value="Persian">Persian</option>
                        <option value="philipine">philipine</option>
                        <option value="Picard">Picard</option>
                        <option value="Piedmontese">Piedmontese</option>
                        <option value="Polish">Polish</option>
                        <option value="Pontic">Pontic</option>
                        <option value="Portuguese">Portuguese</option>
                        <option value="Pulaar">Pulaar</option>
                        <option value="Punjabi">Punjabi</option>
                        <option value="Quechua">Quechua</option>
                        <option value="Quiche">Quiche</option>
                        <option value="Ripuarian">Ripuarian</option>
                        <option value="Romani">Romani</option>
                        <option value="Romanian">Romanian</option>
                        <option value="Romansh">Romansh</option>
                        <option value="Russian">Russian</option>
                        <option value="Rusyn">Rusyn</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="Sakha">Sakha</option>
                        <option value="Sami">Sami</option>
                        <option value="Samoan">Samoan</option>
                        <option value="Samogitian">Samogitian</option>
                        <option value="Sango">Sango</option>
                        <option value="Sangro">Sangro</option>
                        <option value="Sanskrit">Sanskrit</option>
                        <option value="Sara">Sara</option>
                        <option value="Sardinian">Sardinian</option>
                        <option value="Saterland Frisian">Saterland Frisian</option>
                        <option value="Scots">Scots</option>
                        <option value="Scottish Gaelic">Scottish Gaelic</option>
                        <option value="Serbian">Serbian</option>
                        <option value="Serbo">Serbo</option>
                        <option value="Sesotho">Sesotho</option>
                        <option value="Setswana">Setswana</option>
                        <option value="Shanghainese">Shanghainese</option>
                        <option value="Shona">Shona</option>
                        <option value="Sichuan">Sichuan</option>
                        <option value="Sicilian">Sicilian</option>
                        <option value="Silesian">Silesian</option>
                        <option value="Simple English">Simple English</option>
                        <option value="Sindhi">Sindhi</option>
                        <option value="Sinhala">Sinhala</option>
                        <option value="Sinhalese">Sinhalese</option>
                        <option value="siswati">siswati</option>
                        <option value="Slovak">Slovak</option>
                        <option value="Slovene">Slovene</option>
                        <option value="Slovenian">Slovenian</option>
                        <option value="Somali">Somali</option>
                        <option value="Soninke">Soninke</option>
                        <option value="Sorani">Sorani</option>
                        <option value="Sotho">Sotho</option>
                        <option value="Southern Azerbaijani">Southern Azerbaijani</option>
                        <option value="Spanish">Spanish</option>
                        <option value="Sranan">Sranan</option>
                        <option value="Sundanese">Sundanese</option>
                        <option value="Swahili">Swahili</option>
                        <option value="Swati">Swati</option>
                        <option value="Swedish">Swedish</option>
                        <option value="Syriac">Syriac</option>
                        <option value="Tagalog">Tagalog</option>
                        <option value="Tahitian">Tahitian</option>
                        <option value="Taiwanese">Taiwanese</option>
                        <option value="Tajik">Tajik</option>
                        <option value="Tamazight">Tamazight</option>
                        <option value="Tamil">Tamil</option>
                        <option value="Tarantino">Tarantino</option>
                        <option value="Tatar">Tatar</option>
                        <option value="Telugu">Telugu</option>
                        <option value="Teochew">Teochew</option>
                        <option value="Tetum">Tetum</option>
                        <option value="tetun">tetun</option>
                        <option value="Thai">Thai</option>
                        <option value="Tibetan">Tibetan</option>
                        <option value="Tigrigna">Tigrigna</option>
                        <option value="Tigrinya">Tigrinya</option>
                        <option value="Tok Pisin">Tok Pisin</option>
                        <option value="Tongan">Tongan</option>
                        <option value="Tshiluba">Tshiluba</option>
                        <option value="Tsonga">Tsonga</option>
                        <option value="Tswana">Tswana</option>
                        <option value="Tumbuka">Tumbuka</option>
                        <option value="Turkish">Turkish</option>
                        <option value="Turkmen">Turkmen</option>
                        <option value="Tuvan">Tuvan</option>
                        <option value="Twi">Twi</option>
                        <option value="Udmurt">Udmurt</option>
                        <option value="Uighur">Uighur</option>
                        <option value="Ukrainian">Ukrainian</option>
                        <option value="Upper Sorbian">Upper Sorbian</option>
                        <option value="Urdu">Urdu</option>
                        <option value="Uyghur">Uyghur</option>
                        <option value="Uzbek">Uzbek</option>
                        <option value="Venda">Venda</option>
                        <option value="Venetian">Venetian</option>
                        <option value="Vepsian">Vepsian</option>
                        <option value="Vietnamese">Vietnamese</option>
                        <option value="Visayan">Visayan</option>
                        <option value="Volapük">Volapük</option>
                        <option value="Walloon">Walloon</option>
                        <option value="Waray">Waray</option>
                        <option value="Welsh">Welsh</option>
                        <option value="West Flemish">West Flemish</option>
                        <option value="West Frisian">West Frisian</option>
                        <option value="Western Punjabi">Western Punjabi</option>
                        <option value="Wolof">Wolof</option>
                        <option value="Wu">Wu</option>
                        <option value="Xhosa">Xhosa</option>
                        <option value="Yiddish">Yiddish</option>
                        <option value="Yoruba">Yoruba</option>
                        <option value="Zazaki">Zazaki</option>
                        <option value="Zeelandic">Zeelandic</option>
                        <option value="Zhuang">Zhuang</option>
                        <option value="Zulu">Zulu</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group">
                      <input type="text" placeholder="Subject*" class="form-control" id="subject" data-placement="bottom"> </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group ">
                      <select class="plain-select select2_group form-control" id="type_of_service" data-placement="bottom">
                        <option value="">Type of Services</option>
                        <option value="Audio/Video">Audio/Video</option>
                        <option value="book">Book</option>
                        <option value="certified">Certified</option>
                        <option value="certificate">Certificate</option>
                        <option value="document">Document</option>
                        <option value="immigration">Immigration</option>
                        <option value="others">Others</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group" id="hidetrans" style="display: none;">
                      <input id="userscript" type="text" placeholder="Details" class="form-control" data-placement="bottom"> </div>
                    <div class="form-group" id="showtrans">
                      <select class="plain-select select2_group form-control" id="trans" data-placement="bottom">
                        <option value="">Do you need transcription?*</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                    <div class="form-group">
                      <input type="text" placeholder="How Long is Your Video?*" class="form-control" id="video" data-placement="bottom"> </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-12 col-sm-12 col-md-12 mp-pt10">
                    <div class="form-group">
                      <textarea name="InputComment" placeholder="Comments" class="form-control" rows="4" cols="78" id="comment"></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-lg-12">
                  <p class="text-center">✓ 100% privacy we will never spam you <span class="mp-check">
<label class="mp-lab">
<input type="checkbox" id="subscribe" value="" style="margin: 0 6px 0 0;">
Subscribe to receive latest updates
</label>
                   </span> </p>
                </div>
                <div class="clearfix"></div> <a href="#" class="btn btn-sm btn-dark center-block" id="submit" style="width:120px">Submit</a>
                <div align="center" id="msg"></div>
              </div>
          </section>
          <section class="vd-black">
            <div class="container">
              <div class="row">
                <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                  <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                  </div>
                </div>
                <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                  <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
                </div>
              </div>
            </div>
          </section>
          <?php include'vip/testimonial-tag.php';?>
            <?php include'vip/client-tag.php';?>
              <?php include'vip/footer.php';?>
                <?php include'vip/common-js.php';?>
                  <script src="js/common-script.js"></script>
                  <script src="js/select.full.min.js"></script>
                  <script src="js/captioning_quote.js"></script>
                  <script>
                    $('#language').select2({
                      tags: true
                      , tokenSeparators: [',']
                      , placeholder: "Add your target languages*"
                    });
                    $('#trans').change(function () {
                      var val1 = $('#trans').val();
                      if (val1 == 'Yes') {
                        $('#hidetrans').show();
                        $('#showtrans').hide();
                        $('#userscript').focus();
                      }
                      else {
                        $('#showtrans').show();
                      }
                    });
                  </script>
    </body>

    </html>
