<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>

</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-7" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>Superb Features</h1> </div>
            </div>
        </div>
    </div>
</section>

<?php include'vip/number-tag.php';?>

<section class="section">
        <div class="container-fluid">
         <div class="row">
          <div class="col-md-4 no-pm">
            <img src="img/content6.jpg" alt="Image" data-selector="img" class="img-responsive">
          </div>
          <div class="col-md-4 team">
            <div class="font">
              <h3>1000+ Native Professionals</h3>
              <p class="text-muted vd-para">Clients are assured to get only professional results from our online services. Our network of native professionals is composed of college graduates, Ph.D. degree holders, and licensed professional to ensure high-quality output.</p>
            </div>
          </div>
          <div class="col-md-4 team">
            <div class="font">
              <h3>Supports 100+ Languages</h3>
              <p class="text-muted vd-para">Choose your desired language that matches your requirement. We carry different source or target language including Arabic, French, Greek, Chinese, Japanese, and others.</p>
            </div>
          </div>
          <div class="col-md-4 team ">
            <div class="font">
              <h3>Provide Notarization Certificate</h3>
              <p class="text-muted vd-para">Output files can be notarized to ensure quality project results if a client request so.</p>
            </div>
          </div>
          <div class="col-md-4 team ">
            <div class="font">
              <h3>100% USCIS Acceptance</h3>
              <p class="text-muted vd-para">We provide up-to-standard translations, painstaking proofreading for accuracy verbatim in tandem with USCIS requirements and guarantee 100% USCIS Acceptance.</p>
            </div>
          </div>
        </div>
        </div>
</section>

<section class="section bg-white">
        <div class="container-fluid">
         <div class="row">
          <div class="col-md-4 no-pm pull-right">
            <img src="img/content7.jpg" alt="Image" data-selector="img" class="img-responsive">
          </div>
          <div class="col-md-4 team">
            <div class="font">
              <h3>1000+ Native Professionals</h3>
              <p class="text-muted vd-para">Clients are assured to get only professional results from our online services. Our network of native professionals is composed of college graduates, Ph.D. degree holders, and licensed professional to ensure high-quality output.</p>
            </div>
          </div>
          <div class="col-md-4 team">
            <div class="font">
              <h3>Supports 100+ Languages</h3>
              <p class="text-muted vd-para">Choose your desired language that matches your requirement. We carry different source or target language including Arabic, French, Greek, Chinese, Japanese, and others.</p>
            </div>
          </div>
          <div class="col-md-4 team ">
            <div class="font">
              <h3>Provide Notarization Certificate</h3>
              <p class="text-muted vd-para">Output files can be notarized to ensure quality project results if a client request so.</p>
            </div>
          </div>
          <div class="col-md-4 team ">
            <div class="font">
              <h3>100% USCIS Acceptance</h3>
              <p class="text-muted vd-para">We provide up-to-standard translations, painstaking proofreading for accuracy verbatim in tandem with USCIS requirements and guarantee 100% USCIS Acceptance.</p>
            </div>
          </div>
        </div>
        </div>
</section>





<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

    </body>
</html>
