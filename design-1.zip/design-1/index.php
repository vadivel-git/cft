<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>


</head>


    <body>
       <?php include'vip/header.php';?>

       <?php include'vip/home-banner.php';?>
       <?php include'vip/number-tag.php';?>



       <?php include'vip/special-tag.php';?>




        <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1">
                        <img src="img/ipad.png" alt="online services" class="img-responsive">
                    </div>
                </div>
            </div>
        </section>
         <?php include'vip/client-tag.php';?>

  <?php include'vip/testimonial-tag.php';?>

 <?php include'vip/aboutus-tag.php';?>





<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>


    </body>
</html>
