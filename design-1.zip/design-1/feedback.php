<?php include'vip/doctype.php';?>
  <title>Online Services</title>
  <meta name="description" content="Responsive bootstrap landing template">
  <meta name="author" content="Coderthemes">
  <?php include'vip/link-css.php';?>
    <link rel="stylesheet" href="css/select.css"> </head>

    <body>
      <?php include'vip/header.php';?>
        <section class="section-lg home-alt bg-img-4" id="home">
          <div class="bg-overlay1"></div>
          <div class="container">
            <div class="row">
              <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                  <h1>We have all the answers for your queries!</h1> </div>
              </div>
            </div>
          </div>
        </section>
        <?php include'vip/number-tag.php';?>
          <section class="section" id="faqs">
            <div class="container">

              <div class="col-xs-12 col-sm-10 col-lg-8 col-sm-offset-1 col-lg-offset-2">
               <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                  <div class="form-group">
                     <input type="text" placeholder="Full Name*" class="form-control" id="fname" data-placement="bottom">
                  </div>
               </div>
               <div class="col-xs-12 col-sm-6 col-md-6 mp-pt10">
                  <div class="form-group">
                     <input type="text" placeholder="Email Id*" class="form-control" id="femail" data-placement="bottom">
                  </div>
               </div>


               <div class="col-xs-12 col-sm-12 col-md-12 mp-pt10">
                  <div class="form-group">
                     <textarea name="InputComment" placeholder="Give a feedback*" class="form-control" rows="4" cols="78" id="ffeedback" data-placement="bottom"></textarea>
                  </div>
               </div>


               <div class="clearfix"></div>
               <a href="#" class="btn btn-sm btn-dark center-block" id="feedsubmit" style="width:120px">Submit</a>
               <div id="msg" align="center"></div>
            </div>
          </section>
          <section class="vd-black">
            <div class="container">
              <div class="row">
                <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                  <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                  </div>
                </div>
                <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                  <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
                </div>
              </div>
            </div>
          </section>
          <?php include'vip/testimonial-tag.php';?>
            <?php include'vip/client-tag.php';?>
              <?php include'vip/footer.php';?>
                <?php include'vip/common-js.php';?>
                  <script src="js/common-script.js"></script>
                  <script src="js/select.full.min.js"></script>
                  <script src="js/feedback.js"></script>

    </body>

    </html>
