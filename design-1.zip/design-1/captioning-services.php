<?php include'vip/doctype.php';?>

<title>Responsive Multipurpose Landing Page Template</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>
<link href="css/select.css" rel="stylesheet">


</head>


    <body>
       <?php include'vip/header.php';?>

       <?php include'vip/captioning-banner.php';?>
       <?php include'vip/number-tag.php';?>

<section class="section" id="features">
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <div class="tabbable-panel margin-tops4 ">
          <div class="tabbable-line">
            <ul class="nav nav-tabs tabtop  tabsetting">
              <li class="active"> <a href="#tab_default_1" data-toggle="tab">Services</a> </li>
              <li> <a href="#tab_default_2" data-toggle="tab">Features</a> </li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active fade in" id="tab_default_1">
                <div class="heading4">Magento Product Upload Services</div>
                <p class="text-muted vd-para">Transcription is the process of transcribing all sorts of formats including audio, video and image files. It is also the written representation of something. For instance, meetings, conferences, group discussions and many more are transcribed with high quality and accuracy at all times. Our company commits to excellence in transcription quality and service.</p>
                <p class="text-muted vd-para">We have proficient transcribers on board whose expertise and skills are 100% unmatched in this business. They are not just ordinary online workers as they possess good scholastic credentials that conform with our customers’ transcription needs and requirements. All our transcription outputs are carefully checked and reviewed for quality purposes to ensure that highly accepted practices are observed and followed.</p>
              </div>
              <div class="tab-pane fade" id="tab_default_2">
                <div class="heading4">Our List of Features Includes</div>
                <p class="text-muted vd-para vd-list">✓ Supports all file types</p>
                <p class="text-muted vd-para vd-list">✓ NDA agreement</p>
                <p class="text-muted vd-para vd-list">✓ 800+ transcribers</p>
                <p class="text-muted vd-para vd-list">✓ 100+ Languages</p>
                <p class="text-muted vd-para vd-list">✓ 24/7 customer support available</p>
                <p class="text-muted vd-para vd-list">✓ Rush and super rush services available</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="features-alt">
          <h3 class="title">Why Choose Us</h3>
          <p class="text-muted">We make sure your project meets global standards. Step aside and experience our wide range of features. ISO International Standards guarantees that our company’s services are reliable and of good quality. We have the latest techniques and state of the art equipment to tackle today’s global challenges.</p>
        </div>

<!--
        <ul class="text-left vd-circle-list">
          <li><i class="fa fa-circle-o light-color" aria-hidden="true"></i> ISO 9001:2008 Certified</li>
          <li><i class="fa fa-circle-o light-color" aria-hidden="true"></i> Secure and Confidential</li>
          <li><i class="fa fa-circle-o light-color" aria-hidden="true"></i> Best Quality</li>
        </ul>
-->

        <div class="col-sm-12 vd-input1">
          <div class="col-sm-6 margin-4 text-center">
            <span class="vd-input" data-toggle="modal" data-target="#input">Input Sample</span>
            <img data-toggle="modal" data-target="#input" src="img/zoom-out1.png" alt="zoomout" class="img-responsive center-block vd-zoom-img">
          </div>
          <div class="col-sm-6 margin-4 text-center">
            <span class="vd-output" data-toggle="modal" data-target="#output">Output Sample</span>
            <img data-toggle="modal" data-target="#output" src="img/zoom-out2.png" alt="zoomout" class="img-responsive center-block vd-zoom-img">
          </div>
        </div>
        <div class="col-sm-12 text-center">
          <div class="center-block">
            <a href="#" class="btn btn-sm btn-dark">Get Started</a>
          </div>
        </div>

      </div>




      <div class="modal fade" id="input" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header text-center">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
              <h4>Input File</h4> </div>
            <div class="modal-body">
              <div class="demo">
                <div class="panel-group mb-lg" id="accordion" data-toggle="collapse">
                  <img src="img/certified-lang-img.jpg" alt="input" class="img-responsive" style="width: 71%;margin: 0 auto;">
                </div>
              </div>
            </div>
            <!-- container -->
          </div>
        </div>
      </div>

      <div class="modal fade" id="output" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header text-center">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
              <h4>Output Files</h4></div>
            <div class="modal-body">
              <div class="demo">
                <div class="panel-group mb-lg" id="accordion" data-toggle="collapse">
                  <img src="img/authorization-new-lg.png" alt="input" class="img-responsive">
                </div>
              </div>
            </div>
            <!-- container -->
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</section>
<section class="section bg-white" id="clients">
    <div class="container">
        <div class="row text-center">
          <div class="col-sm-6">
                <h2 class="title">Trusted by Price</h2>
                <table id="acrylic">
                    <!-- <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>

                </tr>
            </thead> -->
                    <tbody>
                        <tr>
                            <td>Flat Rate</td>
                            <td>$0.99/min</td>
                        </tr>
                        <tr>
                            <td>Transcription Done by Native Transcribers</td>
                            <td>$1.25/min</td>
                        </tr>
                        <tr>
                            <td>Verbatim</td>
                            <td>$0.25/min</td>
                        </tr>
                        <tr>
                            <td>Time Stamping / Time Coding </td>
                            <td>$0.25/min</td>
                        </tr>
                    </tbody>
                </table>
            </div>
          <?php include'vip/common-language.php';?>
        </div>
    </div>
</section>





 <?php include'vip/testimonial-tag.php';?>


 <?php include'vip/client-tag.php';?>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

<script src="js/select.full.min.js"></script>
<script>
$('#transsource').select2({

    tags: true,
    tokenSeparators: [','],
    placeholder: "Add Source languages"
});
</script>
    </body>
</html>
