<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>

</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-6" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>How it works?</h1> </div>
            </div>
        </div>
    </div>
</section>

       <?php include'vip/number-tag.php';?>

 <section class="section" id="faqs">
            <div class="container">
                <div class="row margin-tops4 text-center">
                    <div class="col-sm-12">
                      <div class="col-sm-4 col-md-4">
                        <div class="funny-boxes float-shadow not-right-column text-center">
                            <span class="funny-boxes-icon">
                                <i class="fa fa-file-text-o"></i>
                            </span>

                            <div class="funny-boxes-text animated flipInY delayp1" style="opacity: 1;">
                                <h4>Ask for a Quote</h4>

                                <p class="text-muted">Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                            </div>
                            <!-- //.funny-boxes-text -->
                        </div>
                        <!-- //.funny-boxes -->
                    </div>
                      <div class="col-sm-4 col-md-4">
                          <div class="funny-boxes float-shadow not-right-column text-center">
                              <span class="funny-boxes-icon">
                                  <i class="fa fa-envelope-o"></i>
                              </span>

                              <div class="funny-boxes-text animated flipInY delayp1" style="opacity: 1;">
                                  <h4>Confirm the Project</h4>

                                  <p class="text-muted">After receiving a confirmation mail from us and within an hour you will receive a free quote with details of your project.</p>
                              </div>
                              <!-- //.funny-boxes-text -->
                          </div>
                          <!-- //.funny-boxes -->
                      </div>
                      <div class="col-sm-4 col-md-4">
                        <div class="funny-boxes float-shadow text-center">
                            <span class="funny-boxes-icon">
                                <i class="fa fa-credit-card"></i>
                            </span>

                            <div class="funny-boxes-text animated flipInY delayp1" style="opacity: 1;">
                                <h4>Pay Online</h4>

                                <p class="text-muted">You will receive an invoice once you accept our. Pay online and we will take care the rest.</p>
                            </div>
                            <!-- //.funny-boxes-text -->
                        </div>
                        <!-- //.funny-boxes -->
                    </div>
                    </div> <!-- end Col -->
                </div>

            </div>
        </section>



<section class="vd-black">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                </div>
            </div>
            <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
            </div>
        </div>
    </div>
</section>





 <?php include'vip/testimonial-tag.php';?>


 <?php include'vip/client-tag.php';?>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

</body>
</html>
