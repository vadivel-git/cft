<?php
include 'server_connect.php';
if(isset($_POST["name"]))
{
$name=$_POST["name"];
$email=$_POST["email"];
$service_type=$_POST['service_type'];
$min=$_POST['min'];
$subject=$_POST["subject"];
$target=$_POST["target"];

$query = mysql_query("INSERT INTO `captioning_quote` (`name`,`email`,`service_type`,`subject`,`minutes`,`target_lang`) VALUES ('$name','$email','$service_type','$subject','$min','$target')");
//$to  = 'vananbackup@gmail.com,support@vananservices.com'; // note the comma
 $to  = 'ananthan.vanan@gmail.com,muthulakshmi.vanan@gmail.com';
// subject
$subject = 'Transcription Quote - Vanan Pro';
// message
$message = '
<html>
<head>
<title>Transcription Quote - Vanan Pro</title>
<style type="text/css">
a, a:link, a:visited {
  color:#000000;
}
.ReadMsgBody {
  background-color: #E8E8E8;
}
</style>
</head>
<body bgcolor="#e8e8e8" style="background-color:#e8e8e8;"><br><br>
<table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
 <tr>
    <td>
      <!--HEADER-->
      <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
        <tr>
          <td colspan="3" height="9"></td>
        </tr>
        <tr>
          <td width="19">&nbsp;</td>
          <td width="587"><table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td><img src=""  border="0" /></td>         
              </tr>
              <tr>
                <td colspan="3" height="21"></td>
              </tr>
              <tr>
                <td colspan="2"><table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
                    <tr>
                      <td><h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">Transcription Quote</h1></td>
               
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          <td width="19">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="3" height="15"></td>
        </tr>
      </table>
      <!--HEADER END--> 
      <!--Headline-->
      <table cellpadding="0" cellspacing="0" border="0" width="624" align="center" bgcolor="#FFFFFF">
  <tr>
    <td>
      <!--HEADER-->
      <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Name : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$name.'</p>
        </td>
        </tr>
        <tr>
        <td height="5"></td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Email ID : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$email.'</p>
        </td>
        </tr>
        <tr>
          <td height="5"></td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Type : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$type.' </p>
        </td>
        </tr>
        
        <tr>
          <td align="left" valign="top"  style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Minutes : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$min.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" valign="top"  style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Source Language : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$source.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" valign="top"  style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Target Language : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$target.' </p>
        </td>
        </tr>
        <tr>
          <td height="5"></td>
        </tr>
      </table>
      <!--Headline End--> 
      
      <!--Exclusions-->
      <!--Exclusions End--></td>
  </tr>
</table>
</body>
</html>';
 // To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: ' . $email . "\r\n";
// Mail it
@mail($to, $subject, $message, $headers);
echo 'Your Request had been send to admin.';
 }
?>
