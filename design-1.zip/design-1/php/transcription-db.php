<?php
if(isset($_POST["name"])){
    $name = $_POST["name"];
    $email = $_POST["email"];
    $country = $_POST["country"];
    $acode = $_POST["acode"];
    $phone = $_POST["phone"];
    $minutes = $_POST["minutes"];
    $turnaround_time = $_POST["turnaround_time"];
    $file_format = $_POST["file_format"];
    $service_type = $_POST["service_type"];
    $source_lang = $_POST["source_lang"];
    $target_lang = $_POST['target_lang'];
    $verbatim = $_POST["verbatim"];
    $time_code = $_POST["time_code"];
    $subscribe = $_POST["subscribe"];
    $comment = $_POST["comment"];

    include_once 'MailChimp.php';
    if($subscribe=='yes')
    {
        $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        
        $mc = new \Drewm\MailChimp('25b1fe0e5e2d8bf7197dfd8ad0bdaab7-us11');
        $mvars = array('optin_ip'=> $_SERVER['REMOTE_ADDR'], 'FNAME' => $name);
        $result = $mc->call('lists/subscribe', array(
            'id'                => 'b207fdf956',
            'email'             => array('email'=>$email),
            'merge_vars'        => $mvars,
            'double_optin'      => true,
            'update_existing'   => false,
            'replace_interests' => false,
            'send_welcome'      => false
          )
        );
    }
    $link = mysql_connect('pricequotecalc.db.9113838.hostedresource.com', 'pricequotecalc', 'kjYU654#'); // Remote server
    if (!$link) {
       die('Could not connect: ' . mysql_error());
    }
    mysql_select_db("pricequotecalc");
    $query1 = mysql_query("SELECT `B` FROM `countrycode` WHERE `A` = '$country'");
    $ccode = mysql_result($query1,0,'B');
    $ctcode = (int)$ccode;
    $phone1 = '+'.$ctcode;
    $phone1 .= ' - '.$acode;
    $phone1 .= ' - '.$phone;
    
include 'server_connect.php';

mysql_query("INSERT INTO `transcription_vananpro` (`name`,`email`,`phone`,`minutes`,`turnaround_time`,`file_format`,`service_type`,`source_lang`,`target_lang`,`verbatim`,`time_code`,`subscribe`,`comment`,`website`) VALUES('$name','$email','$phone1','$minutes','$turnaround_time','$file_format','$service_type','$source_lang','$target_lang','$verbatim','$time_code','$subscribe','$comment','Vanan Pro')");
        
$subject = 'Transcription Quote - Vanan Pro ';
$html_content = '    
<html>
<head>
    <title>Transcription Quote - Vanan Pro</title>
    <style type="text/css">
a, a:link, a:visited {
  color:#000000;
}
.ReadMsgBody {
  background-color: #E8E8E8;
}
</style>
</head>
<body bgcolor="#e8e8e8" style="background-color:#e8e8e8;">
    <br>
        <br>
            <table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
                <tr>
                    <td>
                        <!--HEADER-->
                <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
                <tr>
                    <td colspan="3" height="9"></td>
                </tr>
                <tr>
                    <td width="19">&nbsp;</td>
                    <td width="587">
                        <table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td>
                                    <img src="http://tsus.vanangroupofcomp.netdna-cdn.com/images/Transcription-%20Services%20-%20US%20-%20Logo.png"  border="0" />
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" height="21"></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
                                        <tr>
                                            <td>
                                                <h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">Transcription Quote - Vanan Pro</h1>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="19">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" height="15"></td>
                </tr>
            </table>
            <!--HEADER END-->
            <!--Headline-->
            <table cellpadding="0" cellspacing="0" border="0" width="624" align="center" bgcolor="#FFFFFF">
            <tr>
                <td align="left" style="padding:6px; width:170px;">
                    <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Name : </p>
                </td>
                <td align="left" style="padding:6px;">
                    <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$name.'</p>
                </td>
            </tr>
            <tr>
                <td height="5"></td>
            </tr>
            <tr>
                <td align="left" style="padding:6px; width:170px;">
                    <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Email ID : </p>
                </td>
                <td align="left" style="padding:6px;">
                    <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$email.'</p>
                </td>
            </tr>
            <tr>
                <td height="5"></td>
            </tr>
            <tr>
                <td align="left" style="padding:6px; width:170px;">
                    <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Phone : </p>
                </td>
                <td align="left" style="padding:6px;">
                    <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$phone1.' </p>
                </td>
            </tr>
                
                <tr>
            <td align="left" valign="top"  style="padding:6px; width:170px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Minutes : </p>
            </td>
            <td align="left" style="padding:6px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$minutes.' </p>
            </td>
        </tr>
        <tr>
            <td align="left" valign="top"  style="padding:6px; width:170px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Turnaround Time : </p>
            </td>
            <td align="left" style="padding:6px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$turnaround_time.' </p>
            </td>
        </tr>
        <tr>
            <td align="left" valign="top"  style="padding:6px; width:170px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Input File Format : </p>
            </td>
            <td align="left" style="padding:6px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$file_format.' </p>
            </td>
        </tr>
        <tr>
            <td align="left" valign="top"  style="padding:6px; width:170px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Types of Service : </p>
            </td>
            <td align="left" style="padding:6px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$service_type.' </p>
            </td>
        </tr>
        <tr>
            <td align="left" valign="top"  style="padding:6px; width:170px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Source Language : </p>
            </td>
            <td align="left" style="padding:6px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$source_lang.' </p>
            </td>
        </tr>
        <tr>
            <td align="left" valign="top"  style="padding:6px; width:170px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Target Language : </p>
            </td>
            <td align="left" style="padding:6px;">
                <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$target_lang.' </p>
            </td>
        </tr>
        <tr>
        <td align="left" valign="top"  style="padding:6px; width:170px;">
            <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Comment : </p>
        </td>
        <td align="left" style="padding:6px;">
            <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.nl2br(stripslashes($comment)).' </p>
        </td>
    </tr>
                            <tr>
                                <td height="5"></td>
                            </tr>
                        </table>
                        <!--Headline End-->
                        <!--Exclusions-->
                        <!--Exclusions End-->
                    </td>
                </tr>
            </table>
        </body>
    </html>';
//$to  = 'support@quicktranscriptionservice.com,vananbackup@gmail.com';   
$to = 'anandhan@vananservices.com';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: ' . $email . "\r\n";
@mail($to, $subject, $html_content, $headers);
   
$output = json_encode(array('type'=>'message', 'text'=>'Your request has been sent successfully and you will receive an email from us shortly. Thank you!'));
die($output);
}
else
{
  $output = json_encode(array('type'=>'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
  die($output);
}
?>