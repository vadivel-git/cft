<?php
 
if(isset($_POST["name"]))
{
$name=$_POST["name"];
$email=$_POST["email"];
$cont=$_POST["phone"];
$country=$_POST['country'];
$code=$_POST['acode'];
$sub=$_POST["subject"];
$type_of_service=$_POST["type_of_service"];
$video=$_POST["video"];
$comment=$_POST["comment"];
$language=$_POST['lan'];
$trans=$_POST['trans'];

$link = mysql_connect('pricequotecalc.db.9113838.hostedresource.com', 'pricequotecalc', 'kjYU654#'); // Remote server
if (!$link) {
   die('Could not connect: ' . mysql_error());
}
mysql_select_db("pricequotecalc");
$query1 = mysql_query("SELECT `B` FROM `countrycode` WHERE `A` = '$country'");
$ccode = mysql_result($query1,0,'B');
$ctcode = (int)$ccode;
$phone = '+'.$ctcode;
$phone .= ' - '.$code;
$phone .= ' - '.$cont;
include 'server_connect.php';

mysql_query("INSERT INTO captioning_vananpro (name,email,phone,Language,subject,service,trans,video,comment,website)
values ('$name','$email','$phone','$language','$sub','$type_of_service','$trans','$video','$comment','$website')");
	
//$to  = 'support@vananservices.com,vananbackup@gmail.com'; // note the comma
$to = 'anandhan@vananservices.com';
// subject
$subject = 'Captioning Quote -  Vanan Pro';
// message
$message = '
    <html>
    <head>
        <title>Captioning Quote - Vanan Pro</title>
        <style type="text/css">
  a, a:link, a:visited {
    color:#000000;
  }
  .ReadMsgBody {
    background-color: #E8E8E8;
  }
  </style>
    </head>
    <body bgcolor="#e8e8e8" style="background-color:#e8e8e8;">
        <br>
            <br>
                <table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td>
                            <!--HEADER-->
                            <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
                                <tr>
                                    <td colspan="3" height="9"></td>
                                </tr>
                                <tr>
                                    <td width="19">&nbsp;</td>
                                    <td width="587">
                                        <table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <td>
                                                    <img src="http://www..com/img/VV-logo1.png"  border="0" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" height="21"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
                                                        <tr>
                                                            <td>
                                                                <h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">Captioning Services - Quote</h1>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td width="19">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="3" height="15"></td>
                                </tr>
                            </table>
                            <!--HEADER END-->
                            <!--Headline-->
                            <table cellpadding="0" cellspacing="0" border="0" width="624" align="center" bgcolor="#FFFFFF">
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Name : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$name.'</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="5"></td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Email ID : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$email.'</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="5"></td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Phone : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$phone.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Language(s) : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$language.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Subject : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$sub.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Services You are Interested in : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$type_of_service.' </p>
                                    </td>
                                </tr>
                                 <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Do you need transcription performed by our company? : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$trans.' </p>
                                    </td>
                                </tr>
                                 <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Video Duration : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$video.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Comment : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.nl2br(stripslashes($comment)).' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="5"></td>
                                </tr>
                            </table>
                            <!--Headline End-->
                            <!--Exclusions-->
                            <!--Exclusions End-->
                        </td>
                    </tr>
                </table>
            </body>
        </html>';
 // To send HTML mail, the Content-type header must be set
//$femail='no-reply@visualsubtitling.com';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From:' . $email. "\r\n";
// Mail it
@mail($to, $subject, $message, $headers);
echo 'Your Request had been send to admin.';
}
?>
