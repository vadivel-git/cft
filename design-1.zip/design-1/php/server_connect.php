
<?php
 //$link = mysql_connect('localhost', 'gqueryuser', 'kySR54@'); // Remote server
 $link = mysql_connect('localhost', 'root', 'root'); // local server

if (!$link) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db("test");

?>