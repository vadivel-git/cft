<?php
include("db/server_connect.php");
if(isset($_POST['name']))
{  
  //  Getting and initiating variables For insertation Process
  $name=$_POST['name'];
  $email=$_POST['email'];
  $country=$_POST['country'];
  $code=$_POST['acode'];
  $contact=$_POST['phone'];
  $source=$_POST['source'];
  $count=$_POST['count'];
  $target=$_POST['target'];  
  $qsite=$_POST['qsite'];  
  $qtat=$_POST['qtat'];  
  $qservice=$_POST['qservice'];  
  $comment=$_POST['comment'];  
  $fil=$_POST['filena'];
  $copy=$_POST["copy"];
  $qmail=$_POST["qmail"];
  if($qmail==1)
  {
    $qmail='Yes';
  }
  else
  {
    $qmail='No';
  }
  $qmailmsg=$_POST["qmailmsg"];
  $qnote=$_POST["qnote"];
  if($qnote==1)
  {
    $qnote='Yes';
  }
  else
  {
    $qnote='No';
  }
  if($qmailmsg!=''){
  $qmmsg='
<tr>
    <td align="left" valign="top"  style="padding:6px; width:170px;">
        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Address : </p>
    </td>
    <td align="left" style="padding:6px;">
        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$qmailmsg.' </p>
    </td>
</tr>
<tr>';
  }
  else
  {
    $qmmsg='';
  }
  $filena='';
 // $files=$_POST['file'];
  $s=explode('|,', $fil);
  $fie='';
  $fill='';
  $filink='';
  $cou=count($s)-1;  
  
  for($t=0; $t<$cou; $t++)
  {
     /* if($t!=($cou-1))
      {
          $filena=$filena.$s[$t].",";
          $fie=$fie.$s[$t]."|,";
      }
      else
      {
          $filena=$filena.$s[$t];
           $fie=$fie.$s[$t];
      }*/
      if($t!=($cou-1))
      {
        $fill = str_replace( "\\", '/', $s[$t]);
          // $filena=$filena.basename($fill).",";
          $fie=$fie.basename($fill)."|,";
           
      }
      else
      {
         $fill = str_replace( "\\", '/', $s[$t]);
          // $filena=$filena.basename($fill);
           $fie=$fie.basename($fill);
           
      }
      
     
  }
  //$website='Newyork Translation';
  


mysql_query("INSERT INTO translationsite_quote (Sno, name, email,country,areacode, phone, source_lang, target_lang, ufile, comment, website) values ('','".mysql_real_escape_string(htmlentities($name))."','$email','$country','$code','$contact','$source','$target','".mysql_real_escape_string(htmlentities($fie))."','".mysql_real_escape_string(htmlentities($comment))."','$qsite') ");

  $query = "select max(Sno) as Sno from translationsite_quote";
  $result = mysql_query($query) or trigger_error(mysql_error().$query);
  $row = mysql_fetch_array($result, MYSQL_ASSOC);
  $sno = $row["Sno"];
   for($t=0; $t<$cou; $t++)
  {
     /* if($t!=($cou-1))
      {
          $filena=$filena.$s[$t].",";
          $fie=$fie.$s[$t]."|,";
      }
      else
      {
          $filena=$filena.$s[$t];
           $fie=$fie.$s[$t];
      }*/
      if($t!=($cou-1))
      {
        $fill = str_replace( "\\", '/', $s[$t]);
      
            $filink=$filink.'<a download="'.basename($fill).'" style="color:blue;" href="http://newyork-translation.com/php/files/'.$sno.'/'.basename($fill).'">'.basename($fill).'</a>'." , ";
      }
      else
      {
         $fill = str_replace( "\\", '/', $s[$t]);
        
            $filink=$filink.'<a download="'.basename($fill).'" style="color:blue;" href="http://newyork-translation.com/php/files/'.$sno.'/'.basename($fill).'">'.basename($fill).'</a>';

      }
      
     
  }
 
include_once 'MailChimp.php';
if($copy==1)
{
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    
    $mc = new \Drewm\MailChimp('25b1fe0e5e2d8bf7197dfd8ad0bdaab7-us11');
    $mvars = array('optin_ip'=> $_SERVER['REMOTE_ADDR'], 'FNAME' => $name);
    $result = $mc->call('lists/subscribe', array(
        'id'                => 'b207fdf956',
        'email'             => array('email'=>$email),
        'merge_vars'        => $mvars,
        'double_optin'      => true,
        'update_existing'   => false,
        'replace_interests' => false,
        'send_welcome'      => false
      )
    );
  }
 
  
   @mkdir('files/'.$sno.'/', 0775, true);  
  $files=array();
    for($j=0; $j<($count-1); $j++)
    {


      $file_tmp_name  = $_FILES['file'.$j.'']['tmp_name'];
      $file_name      = $_FILES['file'.$j.'']['name'];
      $file_size      = $_FILES['file'.$j.'']['size'];
      $file_type      = $_FILES['file'.$j.'']['type'];
      $file_error     = $_FILES['file'.$j.'']['error'];
      //$filee = basename(str_replace( "\\", '/', $file_name));
          
      
        $target_path = 'files/'.$sno.'/';  
        $target_path = $target_path.$file_name;
        move_uploaded_file($file_tmp_name, $target_path);

       if($j!=($count-2))
      {
          $fill = str_replace( "\\", '/', $s[$j]);
          $filena=$filena.basename($fill).'('.$file_size.' Bytes),';
         
           
      }
      else
      {
          $fill = str_replace( "\\", '/', $s[$j]);
          $filena=$filena.basename($fill).'('.$file_size.' Bytes)';    
      }
        array_push($files, "files/$sno/$file_name");
      }
       
       
  
/*   $files=array();
  for ($k = 0; $k < $cou; $k++) 
  {               
    array_push($files, "files/$sno/$s[$k]");
  }*/
 
 $link = mysql_connect('pricequotecalc.db.9113838.hostedresource.com', 'pricequotecalc', 'kjYU654#'); // Remote server

//$link = mysql_connect('localhost', 'root', ''); // local server

if (!$link) {

   die('Could not connect: ' . mysql_error());

}
mysql_select_db("pricequotecalc");

$query1 = mysql_query("SELECT `B` FROM `countrycode` WHERE `A` = '$country'");
$ccode = mysql_result($query1,0,'B');

$ctcode = (int)$ccode;
$phone = '+'.$ctcode;
$phone .= ' - '.$code;
$phone .= ' - '.$contact;

//$url = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
$url = 'http://'.$qsite; //$_SERVER['SERVER_NAME'];
$query = mysql_query("SELECT * FROM `projectlist` WHERE `url` = '$url'");
$row=mysql_fetch_array($query);
$proname = $row["name"];

$to  = 'support@vananservices.com,vananbackup@gmail.com';
  //$to  = 'saranya15.vanan@gmail.com,sathishkumar.vanan@gmail.com,praba.vanan@gmail.com';
 
 
 // subject
$subject = 'Translation Quote - '.$proname.'';

// message
 // $message = '
$html_content = '


<html>
<head>
<title>Translation Quote</title>
<style type="text/css">
a, a:link, a:visited {
  color:#000000;
}
.ReadMsgBody {
  background-color: #E8E8E8;
}
</style>
</head>
<body bgcolor="#e8e8e8" style="background-color:#e8e8e8;"><br><br>
<table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
  <tr>
    <td>
      <!--HEADER-->
      <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
        <tr>
          <td colspan="3" height="9"></td>
        </tr>
        <tr>
          <td width="19">&nbsp;</td>
          <td width="587"><table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td><h1><b>'.$proname.'</b></h1></td>         
              </tr>
              <tr>
                <td colspan="3" height="21"></td>
              </tr>
              <tr>
                <td colspan="2"><table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
                    <tr>
                      <td><h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">Translation Quote</h1></td>
               
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          <td width="19">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="3" height="15"></td>
        </tr>
      </table>
      <!--HEADER END--> 
      <!--Headline-->
      <table cellpadding="0" cellspacing="0" border="0" width="624" align="center" bgcolor="#FFFFFF">
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Name : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$name.'</p>
        </td>
        </tr>
        <tr>
          <td height="5"></td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Email ID : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$email.'</p>
        </td>
        </tr>
        <tr>
          <td height="5"></td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Phone Number : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$phone.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Translate From : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$source.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Translate To : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$target.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" valign="top"  style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Files : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$filena.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" valign="top"  style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Files Link : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$filink.' </p>
        </td>
        </tr>

        <tr>
                                        <td align="left" valign="top"  style="padding:6px; width:170px;">
                                            <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Notarized($20/page) : </p>
                                        </td>
                                        <td align="left" style="padding:6px;">
                                            <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$qnote.' </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="left" valign="top"  style="padding:6px; width:170px;">
                                            <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Mailed($15) : </p>
                                        </td>
                                        <td align="left" style="padding:6px;">
                                            <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$qmail.' </p>
                                        </td>
                                    </tr>

        '.$qmmsg.'
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Turaround time : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$qtat.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Service : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$qservice.' </p>
        </td>
        </tr>
        <tr>
          <td align="left" valign="top"  style="padding:6px; width:170px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Comment : </p>
        </td>
        <td align="left" style="padding:6px;">
<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.nl2br(stripslashes($comment)).' </p>
        </td>
        </tr>
        <tr>
          <td height="5"></td>
        </tr>
      </table>
      <!--Headline End--> 
      
      <!--Exclusions-->
      <!--Exclusions End--></td>
  </tr>
</table>
</body>
</html>
';


// $files = array('files/64/06-12-2015 11-41-20 test.txt','files/64/06-12-2015 11-46-27 devi.txt');

$femail=$email;   //'no-reply@'.$qsite; //'no-reply@newyork-translation.com';

function multi_attach_mail($to, $subject, $message, $femail, $name, $files){

   
    $headers = "From: $femail";

    // boundary 
    $semi_rand = md5(time()); 
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 

    // headers for attachment 
    $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 

    // multipart boundary 
    $message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
    "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 

    // preparing attachments
  if(count($files) > 0){
    for($i=0;$i<count($files);$i++){
      if(is_file($files[$i])){
        $message .= "--{$mime_boundary}\n";
        $fp =    fopen($files[$i],"rb");
        $data =  fread($fp,filesize($files[$i]));
        fclose($fp);
        $data = chunk_split(base64_encode($data));
        $message .= "Content-Type: application/octet-stream; name=\"".basename($files[$i])."\"\n" . 
        "Content-Description: ".basename($files[$i])."\n" .
        "Content-Disposition: attachment; filename=\"".basename($files[$i])."\"\n" . 
        "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
      }
    }
  }
    $message .= "--{$mime_boundary}--";
    $returnpath = "-f" . $femail;
  
  //send email
    @mail($to, $subject, $message, $headers, $returnpath); 
  
  //function return true, if email sent, otherwise return fasle
    //if($mail){ return TRUE; } else { return FALSE; }
}


//call multi_attach_mail() function and pass the required arguments
multi_attach_mail($to,$subject,$html_content,$femail,$name,$files);

/*    $headers = "From: $email";

   // boundary 
$semi_rand = md5(time()); 
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
 
// headers for attachment 
$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
 
// multipart boundary 
$message = "This is a multi-part message in MIME format.\n\n" . "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"iso-8859-1\"\n" . "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
$message .= "--{$mime_boundary}\n";
 
// preparing attachments
for($x=0;$x<count($files);$x++){
  $file = fopen($files[$x],"rb");
  $data = fread($file,filesize($files[$x]));
  fclose($file);
  $data = chunk_split(base64_encode($data));
  $message .= "Content-Type: {\"application/octet-stream\"};\n" . " name=\"".basename($files[$x])."\"\n" . 
  "Content-Disposition: attachment;\n" . " filename=\"".basename($files[$x])."\"\n" . 
  "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
  $message .= "--{$mime_boundary}\n";
}*/
 
// send
 
/*$ok = @mail($to, $subject, $message, $headers); */
/*if ($ok) { 
   $output = json_encode(array('type'=>'message', 'text' =>"<p>mail sent to $to!</p>"));
      die($output);
} else { 
  $output = json_encode(array('type'=>'message', 'text' =>'<p>mail could not be sent!</p>'));
      die($output);  
} */
    

$output = json_encode(array('type'=>'message', 'text' =>'Your request has been sent successfully and you will receive an email from us shortly. Thank you!'));
  die($output);

 

  
}
else
{
  $output = json_encode(array('type'=>'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
  die($output);

}

?>