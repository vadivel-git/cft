<?php
include 'server_connect.php';
if(isset($_POST["name"])){
	$name = $_POST["name"];
	$email = $_POST["email"];
	$country = $_POST["country"];
	$acode = $_POST["acode"];
	$phone = $_POST["phone"];
	$service = $_POST["service"];
	$comment = $_POST['comment'];
	mysql_query("INSERT INTO contactus(id,name,email,country,acode,phone,service,comment) VALUES('','$name','$email','$country','$acode',$phone,'$service','$comment')");
	$to  = 'support@vananservices.com,vananbackup@gmail.com'; // note the comma
	//$to  = 'muthulakshmi.vanan@gmail.com,ananthan.vanan@gmail.com';
// subject
	$subject = 'Contact Us - Vanan Pro';
// message
	$message = '
<html>
<head>
   <title>Contact US - Vanan Services</title>
        <style type="text/css">
	a, a:link, a:visited {
	  color:#000000;
	}
	.ReadMsgBody {
	  background-color: #E8E8E8;
	}
	</style>
    </head>
    <body bgcolor="#e8e8e8" style="background-color:#e8e8e8;">
        <br>
            <br>
                <table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td>
                            <!--HEADER-->
                            <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
                                <tr>
                                    <td colspan="3" height="9"></td>
                                </tr>
                                <tr>
                                    <td width="19">&nbsp;</td>
                                    <td width="587">
                                        <table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <td>
                                                    <img src="http://vdtm.in/vanan_logo.png"  border="0" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" height="21"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
                                                        <tr>
                                                            <td>
                                                                <h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">Contact Us</h1>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td width="19">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="3" height="15"></td>
                                </tr>
                            </table>
<br><div align="justify">!!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------!!</div><br /><br />
   <table cellpadding=10 bgcolor=#efefef align="center">
   
   <tr>
      <th align=left>Name </th>  <th align=center>: </th> <th align=left>'.$name.'</th>
    </tr>
	
   <tr>
      <th align=left>Email</th>  <th align=center>: </th> <th align=left>'.$email.'</th>
    </tr>
    <tr>
  		<th align=left>Country</th>  <th align=center>: </th> <th align=left>'.$country.'</th>
	</tr>
	<tr>
	  <th align=left>Area Code</th>  <th align=center>: </th> <th align=left>'.$acode.'</th>
	</tr>
	<tr>
	  <th align=left>Phone</th>  <th align=center>: </th> <th align=left>'.$phone.'</th>
	</tr>
	<tr>
	  <th align=left>Service</th>  <th align=center>: </th> <th align=left>'.$service.'</th>
	</tr>
    <tr>
      <th align=left>Request</th>  <th align=center>: </th><th align=left>'.$comment.'</th>
    </tr>
	
      </table>
  <br>
<br><div align="justify">!!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------!!</div><br />
</body></html>
';
 // To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From:' . $email. "\r\n";
// Mail it
@mail($to, $subject, $message, $headers);
echo 'Your Request had been send to admin.';
}
?>