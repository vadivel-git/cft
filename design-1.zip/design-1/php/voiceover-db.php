<?php
include 'server_connect.php';
if(isset($_POST["name"])){
    $name = $_POST["name"];
    $email = $_POST["email"];
    $country = $_POST["country"];
    $acode = $_POST["acode"];
    $phone = $_POST["phone"];
    $language = $_POST['language'];
    $comment = $_POST['comment'];
    $files=array();
    $copy=$_POST["copy"];
    $message = $_POST["message"];   
    $vscript = $_POST["vscript"];
    $vpurpose = $_POST["vpurpose"];
    $vuserscript = $_POST["vuserscript"];
    $vtrans = $_POST["vtrans"];
    $vnumber = $_POST["vnumber"];
    $vslang = $_POST["vslang"];
    $vtlang = $_POST["vtlang"];
    $vgender = $_POST["vgender1"];
    $vage = $_POST['vage1'];
    $fil=$_POST['filena'];
    $count=$_POST['count'];  
    $filena='';
    $s=explode('|,', $fil);
    
      $fie='';
      $fill='';
      $filink='';
      $cou=count($s)-1;  
      
      for($t=1; $t<$cou; $t++)
      {
          if($t!=($cou-1))
          {
            $fill = str_replace( "\\", '/', $s[$t]);
            $fie=$fie.basename($fill)."|,";
          }
          else
          {
             $fill = str_replace( "\\", '/', $s[$t]);
             $fie=$fie.basename($fill);
          }
      }
    include_once 'MailChimp.php';
    if($copy==1)
    {
        $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        
        $mc = new \Drewm\MailChimp('25b1fe0e5e2d8bf7197dfd8ad0bdaab7-us11');
        $mvars = array('optin_ip'=> $_SERVER['REMOTE_ADDR'], 'FNAME' => $name);
        $result = $mc->call('lists/subscribe', array(
            'id'                => 'b207fdf956',
            'email'             => array('email'=>$email),
            'merge_vars'        => $mvars,
            'double_optin'      => true,
            'update_existing'   => false,
            'replace_interests' => false,
            'send_welcome'      => false
          )
        );
    }

    $query1 = mysql_query("SELECT `B` FROM `countrycode` WHERE `A` = '$country'");
    $ccode = mysql_result($query1,0,'B');
    $ctcode = (int)$ccode;
    $phone1 = '+'.$ctcode;
    $phone1 .= ' - '.$acode;
    $phone1 .= ' - '.$phone;
    

    mysql_query("INSERT INTO voiceover_vananpro(name,email,country,acode,phone,language,script,purpose,userscript,file,need,numberofvoice,slang,tlang,gender,age,comment,site) VALUES('$name','$email','$country','$acode','$phone1','$language','$vscript','$vpurpose','$vuserscript','".mysql_real_escape_string(htmlentities($fie))."','$vtrans ','$vnumber','$vslang','$vtlang','$vgender','$vage','$comment','Vanan Pro')");
        
    $query = "select max(id) as id from voice_tsus";

        $result = mysql_query($query) or trigger_error(mysql_error().$query);
        $row = mysql_fetch_array($result, MYSQL_ASSOC);
        $sno = $row["id"];
        for($t=0; $t<$cou; $t++)
        {
          if($t!=($cou-1))
          {
            $fill = str_replace( "\\", '/', $s[$t]);
                $filink=$filink.'
                                <a download="'.basename($fill).'" style="color:blue;" href="http://www.vananpro.com/vip/form-files/files/Voice/'.$sno.'/'.basename($fill).'">'.basename($fill).'</a>'." , ";
          }
          else
          {
             $fill = str_replace( "\\", '/', $s[$t]);
                $filink=$filink.'
                                <a download="'.basename($fill).'" style="color:blue;" href="http://www.vananpro.com/vip/form-files/files/Voice/'.$sno.'/'.basename($fill).'">'.basename($fill).'</a>';
          }
        }
         
        //$files=array();
        //print_r($count);
        for($j=1; $j<($count-1); $j++)
        {
          $file_tmp_name  = $_FILES['file'.$j.'']['tmp_name'];
          $file_name      = $_FILES['file'.$j.'']['name'];
          $file_size      = $_FILES['file'.$j.'']['size'];
          $file_type      = $_FILES['file'.$j.'']['type'];
          $file_error     = $_FILES['file'.$j.'']['error'];
          //$filee = basename(str_replace( "\\", '/', $file_name));
              
          
            $target_path = 'files/Voice/'.$sno.'/';  
            $target_path = $target_path.$file_name;
            move_uploaded_file($file_tmp_name, $target_path);
           if($j!=($count-2))
          {
              $fill = str_replace( "\\", '/', $s[$j]);
              $filena=$filena.basename($fill).'('.$file_size.' Bytes),';
             
               
          }
          else
          {
              $fill = str_replace( "\\", '/', $s[$j]);
              $filena=$filena.basename($fill).'('.$file_size.' Bytes)';    
          }
            array_push($files, "files/Voice/$sno/$file_name");
          }
    $subject = 'Voice Over Quote - Vanan Pro';

	$html_content = '
	
    <html>
    <head>
        <title>Voice Over Quote - Vanan Pro</title>
        <style type="text/css">
	a, a:link, a:visited {
	  color:#000000;
	}
	.ReadMsgBody {
	  background-color: #E8E8E8;
	}
	</style>
    </head>
    <body bgcolor="#e8e8e8" style="background-color:#e8e8e8;">
        <br>
            <br>
                <table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td>
                            <!--HEADER-->
                            <table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
                                <tr>
                                    <td colspan="3" height="9"></td>
                                </tr>
                                <tr>
                                    <td width="19">&nbsp;</td>
                                    <td width="587">
                                        <table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <td>
                                                    <img src="http://tsus.vanangroupofcomp.netdna-cdn.com/images/Transcription-%20Services%20-%20US%20-%20Logo.png"  border="0" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" height="21"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
                                                        <tr>
                                                            <td>
                                                                <h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">Voice Over Services - Quote</h1>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td width="19">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="3" height="15"></td>
                                </tr>
                            </table>
                            <!--HEADER END-->
                            <!--Headline-->
                            <table cellpadding="0" cellspacing="0" border="0" width="624" align="center" bgcolor="#FFFFFF">
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Name : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$name.'</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="5"></td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Email ID : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$email.'</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="5"></td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Country : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$country.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Area Code : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$acode.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Phone : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$phone1.' </p>
                                    </td>
                                </tr>
                               
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Language : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$language.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Script : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vscript.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Purpose for Voice Over  : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vpurpose.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Your Script : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vuserscript.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Files : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$filena.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Files Link : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$filink.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Need Translation : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vtrans.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Number of Voices : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vnumber.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Source Language : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vslang.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Target Language : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vtlang.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Gender : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vgender.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:190px;">Age : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.$vage.' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" valign="top"  style="padding:6px; width:170px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Comment : </p>
                                    </td>
                                    <td align="left" style="padding:6px;">
                                        <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">'.nl2br(stripslashes($comment)).' </p>
                                    </td>
                                </tr>
                                <tr>
                                    <td height="5"></td>
                                </tr>
                            </table>
                            <!--Headline End-->
                            <!--Exclusions-->
                            <!--Exclusions End-->
                        </td>
                    </tr>
                </table>
            </body>
        </html>';
//$to  = 'support@quicktranscriptionservice.com,vananbackup@gmail.com';	
$to  = 'anandhan@vananservices.com';
	
	function multi_attach_mail($to, $subject, $message, $email, $name, $files){
   
    $headers = "From: $email";
    // boundary 
    $semi_rand = md5(time()); 
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
    // headers for attachment 
    $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
    // multipart boundary 
    $message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
    "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
    // preparing attachments
	  if(count($files) > 0){
	    for($i=0;$i
        <count($files);$i++){
	      if(is_file($files[$i])){
	        $message .= "--{$mime_boundary}\n";
	        $fp =    fopen($files[$i],"rb");
	        $data =  fread($fp,filesize($files[$i]));
	        fclose($fp);
	        $data = chunk_split(base64_encode($data));
	        $message .= "Content-Type: application/octet-stream; name=\"".basename($files[$i])."\"\n" . 
	        "Content-Description: ".basename($files[$i])."\n" .
	        "Content-Disposition: attachment; filename=\"".basename($files[$i])."\"\n" . 
	        "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
	      }
	    }
	  }
    $message .= "--{$mime_boundary}--";
    $returnpath = "-f" . $email;
  
  //send email
    @mail($to, $subject, $message, $headers, $returnpath); 
  
  //function return true, if email sent, otherwise return fasle
    //if($mail){ return TRUE; } else { return FALSE; }
	}
	//call multi_attach_mail() function and pass the required arguments
	multi_attach_mail($to,$subject,$html_content,$email,$name,$files);
		
		 
	$output = json_encode(array('type'=>'message', 'text'=>'Your request has been sent successfully and you will receive an email from us shortly. Thank you!'));
  	die($output);
	}
	else
	{
	  $output = json_encode(array('type'=>'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
	  die($output);
	}
?>