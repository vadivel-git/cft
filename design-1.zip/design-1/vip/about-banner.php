<section class="section-lg home-alt bg-img-2" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>Special Offers</h1> </div>
            </div>
        </div>
    </div>
</section>
