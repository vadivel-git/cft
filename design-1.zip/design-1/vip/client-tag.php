<section class="section bg-white" id="clients">
    <div class="container">
        <div class="row text-center">
            <div class="col-sm-12">
                <h2 class="title">Trusted by Thousands</h2>
                <p class="slogan">Lorem ipsum dolor sit amet, consectetur adipis.</p>
                <div class="carousel-wrap">
  <div class="owl-carousel">
    <div class="item"><img src="http://vanandesk.com/img/client1.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client2.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client3.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client4.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client5.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client6.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client7.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client8.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client9.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client10.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client11.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client12.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client13.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client14.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client15.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client16.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client17.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client18.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client19.png"></div>
    <div class="item"><img src="http://vanandesk.com/img/client20.png"></div>
  </div>
</div>

            </div>

        </div>
    </div>
</section>


