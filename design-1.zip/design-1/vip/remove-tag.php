<section class="section bg-white">
<div class="container">
    <div class="row text-center">
    <h2 class="title">What we do!</h2>
    <p class="title-alt">Looks beautiful &amp; ultra-sharp on Retina Screen Displays. Retina Icons, Fonts &amp; all <br> others graphics are optimized.</p>
    </div>

<!--block 1-->
<div class="row text-left">
<div class="col-md-4 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-list icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Branding</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-4 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diploma icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Branding</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-4 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-internet icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Branding</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
</div>
<!--block 1-->

<!--block 2-->
<div class="row text-left">
<div class="col-md-4 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diamond icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Branding</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-4 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diamond icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Branding</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-4 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diamond icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Branding</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
</div>
<!--block 2-->
</div>
</section>