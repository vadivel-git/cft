<div class="col-sm-6">
                <h2 class="title">Features</h2>
                <p class="text-muted vd-text">We make sure your project meets global standards. Step aside and experience our wide range of features. ISO International Standards guarantees that our company’s services are reliable and of good quality.</p>

                  <div class="feat-facts">
                    <div class="feat-facts-box">
                        <h2><i class="icon-like"></i></h2>
                        <h4>564</h4>
                        <p>Completed Projects</p>
                    </div>
                    <div class="feat-facts-box">
                        <h2><i class="icon-users"></i></h2>
                        <h4>8960</h4>
                        <p>Happy Clients</p>
                    </div>
                    <div class="feat-facts-box">
                        <h2><i class="icon-download"></i></h2>
                        <h4>8954</h4>
                        <p>Total Download</p>
                    </div>
                </div>
                <div class="col-md-6 vd-modal" data-toggle="modal" data-target="#squarespaceModal"> <i class="fa fa-hand-o-right mp-point" aria-hidden="true"></i> <span class="mp-range">Wide Range of Services</span> </div>
                <div class="modal fade" id="squarespaceModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                <h4 class="modal-title vd-title" id="myModalLabel">LIST OF SERVICES</h4> </div>
                            <div class="modal-body">
                                <div class="demo">
                                    <div class="panel-group mb-lg" id="accordion" data-toggle="collapse">
                                        <div class="panel panel-default">
                                            <div class="panel-heading collapsed">
                                                <h5 class="panel-title"><a class="" data-toggle="collapse" data-parent="#accordion" data-target="#collapseOne" aria-expanded="true">Collapsible Group Item <i class="fa fa-angle-down pull-right"></i></a></h5></div>
                                            <div id="collapseOne" class="panel-collapse collapse in" aria-expanded="true">
                                                <div class="panel-body">Get base styles and flexible support for collapsible components like accordions and navigation. Using the collapse plugin, we built a simple accordion by extending the panel component.</div>
                                            </div>
                                        </div>
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h5 class="panel-title"><a class="collapsed" data-toggle="collapse" data-parent="#accordion" data-target="#collapsetwo" aria-expanded="false">Check It <i class="fa fa-angle-down pull-right"></i></a></h5></div>
                                            <div id="collapsetwo" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                                <div class="panel-body">Why don't use Lore Ipsum? I think if some one says don't use lore ipsum it's very controversial point. I think the opposite actually.</div>
                                            </div>
                                        </div>
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h5 class="panel-title"><a class="collapsed" data-toggle="collapse" data-parent="#accordion" data-target="#collapseThree" aria-expanded="false">Check It <i class="fa fa-angle-down pull-right"></i></a></h5></div>
                                            <div id="collapseThree" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                                <div class="panel-body">Why don't use Lore Ipsum? I think if some one says don't use lore ipsum it's very controversial point. I think the opposite actually.</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- container -->
                        </div>
                    </div>
                </div>
                <div class="col-md-6 vd-modal" data-toggle="modal" data-target="#squarespaceModal1"> <i class="fa fa-hand-o-right mp-point" aria-hidden="true"></i> <span class="mp-range"> Multi-Lingual Support</span> </div>
                <div class="modal fade" id="squarespaceModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                <h4 class="modal-title vd-title" id="myModalLabel">LIST OF LANGUAGES</h4> </div>
                            <div class="modal-body mp-scroll">
                                <div class="demo">
                                    <div class="row alphapat1 text-center"> <a class="alphapat page-scroll" href="#A">A</a> <a class="alphapat page-scroll" href="#B">B</a> <a class="alphapat page-scroll" href="#C">C</a> <a class="alphapat page-scroll" href="#D">D</a> <a class="alphapat page-scroll" href="#E">E</a> <a class="alphapat page-scroll" href="#F">F</a> <a class="alphapat page-scroll" href="#G">G</a> <a class="alphapat page-scroll" href="#H">H</a> <a class="alphapat page-scroll" href="#I">I</a> <a class="alphapat page-scroll" href="#J">J</a> <a class="alphapat page-scroll" href="#K">K</a> <a class="alphapat page-scroll" href="#L">L</a> <a class="alphapat page-scroll" href="#M">M</a> <a class="alphapat page-scroll" href="#N">N</a> <a class="alphapat page-scroll" href="#O">O</a> <a class="alphapat page-scroll" href="#P">P</a> <a class="alphapat page-scroll" href="#Q">Q</a> <a class="alphapat page-scroll" href="#R">R</a> <a class="alphapat page-scroll" href="#S">S</a> <a class="alphapat page-scroll" href="#T">T</a> <a class="alphapat page-scroll" href="#U">U</a> <a class="alphapat page-scroll" href="#V">V</a> <a class="alphapat page-scroll" href="#W">W</a> <a class="alphapat page-scroll" href="#X">X</a> <a class="alphapat page-scroll" href="#Y">Y</a> <a class="alphapat page-scroll" href="#Z">Z</a> </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="A"><a name="A"></a>A</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Abkhazian" class="r1"> Abkhazian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Acholi" class="r1">Acholi</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Afar" class="r1">Afar</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Afrikaans" class="r1">Afrikaans<a/></p>
   <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Akan">Akan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Albanian">Albanian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Amharic">Amharic</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Arabic">Arabic</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Armenian">Armenian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ashanti">Ashanti</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Assamese">Assamese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Assyrian">Assyrian</a></p>
                                        <p class="inner-list new-list" id="searchtext"><a href="Transcription-Quote.php?language=Aymara">Aymara</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Azerbaijani">Azerbaijani</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="B"><a name="B"></a>B</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bahasa">Bahasa</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bambara">Bambara</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bashkir">Bashkir</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bengali">Bengali</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bhutani">Bhutani</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bihari">Bihari</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bislama">Bislama</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bosnian">Bosnian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Breton">Breton</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Bulgarian">Bulgarian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Burmese">Burmese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Byelorussian">Byelorussian</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="C"><a name="C"></a>C</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Cambodian">Cambodian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Cantonese">Cantonese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Catalan"> Catalan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Cape">Cape</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Cebuano">Cebuano</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Chewa">Chewa</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Chinese Simplified">Chinese Simplified</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Chinese Traditional">Chinese Traditional</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Chamorro">Chamorro</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Cherokee">Cherokee</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Chinese">Chinese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Chuukese">Chuukese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Corsican">Corsican</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Croatian">Croatian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Czech">Czech</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="D"><a name="D"></a>D</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Danish">Danish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Dari">Dari</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Dinka">Dinka</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Divehi">Divehi</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Dutch">Dutch</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Dzongkha">Dzongkha</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="E"><a name="E"></a>E</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Edo">Edo</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Efik">Efik</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=English">English</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Esperanto">Esperanto</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Estonian">Estonian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ethiopian">Ethiopian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ewé">Ewé</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="F"><a name="F"></a>F</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Faeroese">Faeroese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Farsi">Farsi</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Fiji">Fiji</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Fijian">Fijian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Finnish">Finnish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Flemish">Flemish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=French">French</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Frisian">Frisian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Fula">Fula</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Fulani">Fulani</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Fulfulde">Fulfulde</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="G"><a name="G"></a>G</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ga">Ga</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Gaelic">Gaelic</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Gaelic Manx">Gaelic Manx</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Gaelic Scot">Gaelic Scot</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Galician">Galician</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Georgian">Georgian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=German">German</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Greek">Greek</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Greenlandic">Greenlandic</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Guarani">Guarani</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Gujarati">Gujarati</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="H"><a name="H"></a>H</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Haitian">Haitian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hakka">Hakka</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hausa">Hausa</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hawaiian">Hawaiian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=he, iw*">he, iw*</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hebrew">Hebrew</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hindi">Hindi</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hmong">Hmong</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ho">Ho</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Hungarian">Hungarian</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="I"><a name="I"></a>I</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ibibio">Ibibio</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Icelandic">Icelandic</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Igbo">Igbo</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=id, in*">id, in*</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ilocano">Ilocano</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Interlingue">Interlingue</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Indonesian">Indonesian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Interlingua">Interlingua</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Inuktitut">Inuktitut</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Irish">Irish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Italian">Italian</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="J"><a name="J"></a>J</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Japanese">Japanese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Javanese">Javanese</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="K"><a name="K"></a>K</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kanjobal">Kanjobal</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kannada">Kannada</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Karen">Karen</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kashmiri">Kashmiri</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kazakh">Kazakh</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Khmer">Khmer</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kikuyu">Kikuyu</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kinyarwanda">Kinyarwanda</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kirghiz">Kirghiz</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kirundi">Kirundi</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=konkani">konkani</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Korean">Korean</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Kurdish">Kurdish</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="L"><a name="L"></a>L</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Laotian">Laotian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Latin">Latin</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Latvian">Latvian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Lebanese">Lebanese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Lingala">Lingala</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Lithuanian">Lithuanian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Luganda">Luganda</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="M"><a name="M"></a>M</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Macedonian">Macedonian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Malagasy">Malagasy</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Malay">Malay</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Malayalam">Malayalam</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Maltese">Maltese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mam">Mam</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mandarin">Mandarin</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mandingo">Mandingo</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mandinka">Mandinka</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Maori">Maori</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Marathi">Marathi</p>
   </a>
                                            <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Marshallese">Marshallese</a></p>
                                            <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mien">Mien</a></p>
                                            <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mina">Mina</a></p>
                                            <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Moldovan">Moldovan</a></p>
                                            <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Mongolian">Mongolian</a></p>
                                            <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Moroccan">Moroccan</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="N"><a name="N"></a>N</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Navajo">Navajo</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Nepali">Nepali</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Norwegian">Norwegian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Norwegian">Nuer</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="O"><a name="O"></a>O</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Occitan">Occitan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Oriya">Oriya</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Oromo">Oromo</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="P"><a name="P"></a>P</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Papiamento">Papiamento</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Papiamentu">Papiamentu</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Pashto">Pashto</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=philipine">philipine</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Polish">Polish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Portuguese">Portuguese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Pulaar">Pulaar</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Punjabi">Punjabi</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="Q"><a name="Q"></a>Q</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Quechua">Quechua</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Quiche">Quiche</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="R"><a name="R"></a>R</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Romanian">Romanian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Russian">Russian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Rwanda">Rwanda</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="S"><a name="S"></a>S</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sami">Sami</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Samoan">Samoan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Samoan">Sangro</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sanskrit">Sanskrit</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sara">Sara</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Serbian">Serbian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Serbo">Serbo</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sesotho">Sesotho</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Setswana">Setswana</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Shanghainese">Shanghainese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Shona">Shona</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sichuan">Sichuan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sicilian">Sicilian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sindhi">Sindhi</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sinhala">Sinhala</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Slovenian">Slovenian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sinhalese">Sinhalese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=siswati">siswati</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Slovak">Slovak</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Slovene">Slovene</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Slovenian">Slovenian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Somali">Somali</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Soninke">Soninke</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sorani">Sorani</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sotho">Sotho</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Spanish">Spanish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Sudanese">Sudanese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Swahili">Swahili</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Swedish">Swedish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Syriac">Syriac</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="T"><a name="T"></a>T</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tagalog">Tagalog</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tahitian">Tahitian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Taiwanese">Taiwanese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tamazight">Tamazight</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tamil">Tamil</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tatar">Tatar</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Telugu">Telugu</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Teochew">Teochew</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=tetun">tetun</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Thai">Thai</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tibetan">Tibetan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tigrigna">Tigrigna</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tongan">Tongan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tshiluba">Tshiluba</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Tsonga">Tsonga</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Turkish">Turkish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Turkmen">Turkmen</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Twi">Twi</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="U"><a name="U"></a>U</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Uighur">Uighur</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Ukrainian">Ukrainian</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Urdu">Urdu</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Uzbek">Uzbek</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="V"><a name="V"></a>V</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=venda">venda</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Vietnamese">Vietnamese</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Visayan">Visayan</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Volapük">Volapük</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="W"><a name="W"></a>W</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Welsh">Welsh</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Wolof">Wolof</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="X"><a name="X"></a>X</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=xhosa">xhosa</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=yi, ji*">yi, ji*</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="Y"><a name="Y"></a>Y</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Yiddish">Yiddish</a></p>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Yoruba">Yoruba</a></p>
                                    </div>
                                    <div class="list">
                                        <h2 class="VD-new-new" id="Z"><a name="Z"></a>Z</h2>
                                        <p class="inner-list new-list"><a href="Transcription-Quote.php?language=Zulu">Zulu</a></p>
                                        <p class="inner-list new-list">And More</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- container -->
                        </div>
                    </div>
                </div>





            </div>