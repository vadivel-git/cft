<section class="section">
    <div class="container">
        <div class="row text-center">
            <div class="col-sm-12">
                <h2 class="title">Tesitmonial</h2>
                <p class="slogan">Lorem ipsum dolor sit amet, consectetur adipis.</p>
<div class="col-md-8 col-md-offset-2 text-center">
                        <div>
                            <img src="img/quote-icon.png" alt="quote" class="center-block">
                            <h4 class="testi-text">I have been using this template for all my company needs for the last 3 years and couldn’t be happier with their service and expertise. They’ve surpassed all of my expectations and customer service!</h4>
                            <div class="m-t-10">
                                <img src="img/testi-1.jpg" alt="clients" class="img-circle center-block testi-img">
                                <p class="m-t-10"><strong>Mark Wainright</strong> <br>
                                CEO &amp; Founder of Another Great Company</p>
                            </div>
                        </div>
                    </div>

            </div>

        </div>
    </div>
</section>

