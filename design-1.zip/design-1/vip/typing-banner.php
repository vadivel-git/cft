<section class="section-lg home-alt bg-img" id="home">
            <div class="bg-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 text-left">
                        <div class="home-wrapper">
                        <h1>Typing Services at <span class="vd-colred">$2.00</span>/page</h1>
                             <p class="vd-para">Audio or video files of any file formats can easily be transcribed by skilled and talented transcribers that can also do transcription to various global languages. Guaranteed accuracy that follows global transcription standard.</p>

                            <a href="" class="btn btn-white">Get Started</a>

                            <div class="clearfix"></div>

                            <a href="http://vimeo.com/99025203" class="video-btn btn popup-video"><i class="icon-play-button-1"></i>Watch Video</a>

                        </div>
                    </div>


<div class="col-sm-4 col-sm-offset-2">
                        <div class="home-wrapper">
                            <form role="form" id="#" class="intro-form">
                                <h3 class="text-center"> Ask for a Quote Now! </h3>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Email Id" required="required">
                                </div>
                                <div class="form-group">
                                <select class="form-control plain-select" id="ttype" data-placement="bottom">
                                    <option value="">Formatting</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="How Many Pages" required="required">
                                </div>
                                <div class="form-group text-center">
                                    <button type="submit" class="btn btn-custom btn-sm">Start Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
