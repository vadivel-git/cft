
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="facts-box text-center">
                            <div class="row">
                                <div class="col-sm-3 col-xs-6">
                                    <h2>ISO</h2>
                                    <p class="text-muted">9001:2008 CERTIFIED</p>
                                </div>

                                <div class="col-sm-3 col-xs-6">
                                    <h2>100%</h2>
                                    <p class="text-muted">SECURE & CONFIDENTIAL</p>
                                </div>

                                <div class="col-sm-3 col-xs-6">
                                    <h2>98%</h2>
                                    <p class="text-muted">BEST QUALITY</p>
                                </div>

                                <div class="col-sm-3 col-xs-6 cursor" onclick="parent.LC_API.open_chat_window()">
                                    <h2 class="vd-call">24/7</h2>
                                    <p class="text-muted">Customer Support</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
