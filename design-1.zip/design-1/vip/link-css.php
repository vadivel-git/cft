<!-- Google Fonts -->
<link href='https://fonts.googleapis.com/css?family=Josefin+Sans:400,600,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto:400,500,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<!-- Animate CSS -->
<link href="css/animate.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="css/flaticon.css">


<link rel="stylesheet" href="css/owl.carousel.css">
<link rel="stylesheet" href="http://coderthemes.com/metrico_1.3/css/magnific-popup.css">
