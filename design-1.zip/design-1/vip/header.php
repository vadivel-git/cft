<nav class="navbar navbar-default navbar-custom navbar-custom-dark sticky bg-trans">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
<!--                    <img src="img/logo_white.png" class="logo logo-white" alt="logo"><img src="img/logo.png" class="logo logo-dark hidden" alt="logo"> -->
                   Logo
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
<li>
    <form class="navbar-form full-width">
        <div class="form-group vd-res-search">
            <input type="text" class="form-control form-vd" placeholder="search">
            <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
        </div>
    </form>
</li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">Services <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="transcription-services.php">Transcription</a></li>
                                <li><a href="translation-services.php">Translation</a></li>
                                <li><a href="captioning-services.php">Captioning</a></li>
                                <li><a href="voiceover-services.php">Voiceover</a></li>
                                <li><a href="typing-services.php">Typing</a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                        </li>
                        <li><a href="how-it-works.php" class="scroll">How it Works</a></li>
                        <li><a href="#features" class="scroll">Pricing</a></li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">Support<i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="clients-testimonial.php">clients-testimonial</a></li>
                                <li><a href="faq.php">faq</a></li>
                                <li><a href="feedback.php">feedback</a></li>
                                <li><a href="upload-files.php">upload-files</a></li>
                                <li><a href="terms-condition.php">terms-condition</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                         <a class="dropdown-toggle vd-btn" data-toggle="dropdown" data-hover="dropdown" href="#">Quote <i class="fa fa-angle-down"></i></a>
                       <ul class="dropdown-menu">
                                <li><a href="clients-testimonial.php">clients-testimonial</a></li>
                                <li><a href="faq.php">faq</a></li>
                                <li><a href="inner.php">inner</a></li>
                                <li><a href="offers.php">Offers</a></li>
                                <li><a href="remove.php">Remove</a></li>
                                <li><a href="transcription-rate.php">Transcription-rate</a></li>
                                <li><a href="why-choose-us.php">why-choose-us</a></li>
                            </ul>

                        </li>
<!--                        <li><a href="#faqs" class="scroll vd-upbtn">Upload</a></li>-->
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>






