<section class="section bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
               <div class="text-center">
                 <div class="mouse-icon" data-toggle="tooltip" data-placement="bottom" title="Scrol Top" id="back-to-top" ><div class="icon icon-eject wheel"></div></div>
               </div>
                <div class="text-center subscribe-form">
                    <h3>Subscribe to recive free updates!</h3>
                    <form action="#">
                        <input type="text" placeholder="Email">
                        <button type="submit">Subscribe</button>
                    </form>
                </div>
            </div>
            <!-- end Col -->
        </div>
    </div>
</section>

<footer class="bg-dark footer-one">
          <div class="container">
            <div class="row">

              <div class="col-md-4 col-sm-6 p-b-40">
              logo
<!--              <img src="img/logo_white.png" alt="logo" class="footer-logo" height="40">-->
              <p class="text-light about-text">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC,making it over 2000 years old.</p>
              <p class="text-light about-text">Nunc nec dui vitae urna cursus lacinia. In venenatis egetjusto in dictum.</p>
            </div>

            <div class="col-md-2 col-sm-6">
              <h5>Company</h5>
              <ul class="list-unstyled">
                <li><a href="">About Us</a></li>
                <li><a href="">Features</a></li>
                <li><a href="">FAQ</a></li>
                <li><a href="">Services</a></li>
              </ul>
            </div>

            <div class="col-md-3 col-sm-6 p-b-40 col-md-offset-1">
              <h5>Support</h5>
              <ul class="list-unstyled">
                <li><a href="">Help &amp; Support</a></li>
                <li><a href="">Privacy Policy</a></li>
                <li><a href="">Terms &amp; Conditions</a></li>
              </ul>
            </div>

              <div class="col-md-2">
                <div class="vd-res-left pull-right">
                <h5>Payment Option</h5>
                <ul class="list-unstyled">
                  <li><img src="img/paypal.png" alt="pay pal"></li>
                </ul>
                </div>
                </div>


            </div>
          </div>

          <div class="footer-one-alt">
            <div class="container">
              <div class="row">
                <div class="col-sm-5">
                  <p class="m-b-0 font-13 copyright">© 2016 My Design. Design by Design</p>
                </div>
                <div class="col-sm-7">
                  <ul class="list-inline footer-social-one m-b-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        </footer>

<!--fixed-navbar-->
<div class="theme-config">
    <div class="theme-config-box">
        <div class="spin-icon">
            <i class="fa fa-phone"></i>
        </div>
        <div class="skin-setttings">
            <div class="title">Free 24/7 phone support</div>
            <div class="setings-item">
                <span><span class="vd-colred">US</span> : 1-888-535-5668</span>
            </div>
            <div class="setings-item">
                <span><span class="vd-colred">UK</span> : +44-80-8238-0078</span>
            </div>
            <div class="setings-item">
            <span><span class="vd-colred">AUS </span>: +61-1-8003-57380</span>
            </div>
        </div>
    </div>
</div>

<div id="fixedsocial">
  <div class="vd-side">
    <a href="#" data-toggle="tooltip" data-placement="left" title="Carrer">
      <i class="icon icon-briefcase"></i>
    </a>
    <hr class="vd-hr">
    <a href="#" onClick="addBookmark()" data-toggle="tooltip" data-placement="left" title="Bookmark">
      <i class="icon icon-bookmark"></i>
    </a>
    <hr class="vd-hr">
    <a href="feedback.php" data-toggle="tooltip" data-placement="left" title="Feedback">
      <i class="icon icon-users-1"></i>
    </a>

  </div>
</div>



