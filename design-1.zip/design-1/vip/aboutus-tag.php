<section class="section bg-white">
<div class="container">
<div class="row vertical-content">

                    <div class="col-sm-6">
                        <img src="img/people.png" class="img-responsive vd-m" alt="about us">
                    </div>

                    <div class="col-sm-6">
                        <div class="features-alt">
                            <div class="feature-alt-icon">
                                <i class="pe-7s-bicycle"></i>
                            </div>
                            <h3>About Us </h3>

                            <p class="text-muted">We put a lot of effort in design, as it’s the most important ingredient of successful website.Sed ut perspiciatis unde omnis iste natus error sit.We put a lot of effort in design, as it’s the most important ingredient of successful website.</p>

                            <a href="#" class="btn btn-sm btn-dark">Offers</a>
                            <a href="#" class="btn btn-sm btn-custom">Features</a>


                           <p class="vd-colred vd-pad">
                            <span><i class="fa fa-phone"></i></span>
                            <span class="vd-us">US</span> : 1-888-535-5668
                            <span class="vd-us">UK</span> : +44-80-8238-0078
                            <span class="vd-us">AUS</span> : +61-1-8003-57380
                            </p>
                        </div>
                    </div>

                </div>
</div>
</section>
