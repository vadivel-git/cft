<section class="section" id="features">
            <div class="container">

                <div class="row">
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon-const">
                                <i class="icon-folder-14 icon-fa"></i>
                            </div>
                            <h3>Transcription</h3>

                            <p class="text-muted">Full suite of benefits minus the extra cost. Flawless results always within your budget.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon-const">
                                <i class="icon-internet icon-fa"></i>
                            </div>
                            <h3>Translation</h3>

                            <p class="text-muted">Unmatched translation quality with expert linguists and superb 24/7 customer service all rolled into one.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon-const">
                                <i class="icon-television-1 icon-fa"></i>
                            </div>
                            <h3>Captioning</h3>

                            <p class="text-muted">Easy-to-use service without the hassle. Ordering takes less than a minute.</p>
                        </div>
                    </div>
                </div>

                <div class="row home-const-services">
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon-const">
                                <i class="icon-speaker-4 icon-fa"></i>
                            </div>
                            <h3>Voice Over</h3>

                            <p class="text-muted">Full suite of benefits minus the extra cost. Flawless results always within your budget.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon-const">
                                <i class="icon-user-7 icon-fa"></i>
                            </div>
                            <h3>Typing</h3>

                            <p class="text-muted">Unmatched translation quality with expert linguists and superb 24/7 customer service all rolled into one.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="features-box text-center">
                            <div class="feature-icon-const">
                                <i class="icon-edit icon-fa"></i>
                            </div>
                            <h3>Writing</h3>

                            <p class="text-muted">Easy-to-use service without the hassle. Ordering takes less than a minute.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>
