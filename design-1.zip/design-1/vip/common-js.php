<!-- js placed at the end of the document so the pages load faster -->
<script src="js/jquery-2.1.4.min.js"></script>
<?php if(!isset($CRMFORM)) { ?>
  <script src="js/bootstrap.min.js"></script>
<?php } ?>
    <!-- Jquery easing -->
    <script type="text/javascript" src="js/jquery.easing.1.3.min.js"></script>
    <!--sticky header-->
    <script type="text/javascript" src="js/jquery.sticky.js"></script>
    <!--common script for all pages-->
    <script src="js/jquery.app.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.lettering.js"></script>
    <script src="js/jquery.textillate.js"></script>
    <script src="js/fixed-navbar.js"></script>
    <script src="http://coderthemes.com/metrico_1.3/js/jquery.magnific-popup.min.js"></script>
