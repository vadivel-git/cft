 <section class="section-lg home-alt bg-gradient" id="home">
            <div class="container">
                <div class="row">
                    <div class="col-md-7 center-page">
                        <div class="home-wrapper text-center">
                            <p class="text-muted">All New Ultimate Destination For</p>
                            <div class="tlt">
                                <ul class="texts">
                                    <li>Online Services is a fully responsive landing page template</li>
                                    <li>It's designed for describing your app, agency or business</li>
                                </ul>
                            </div>

                            <a href="#" class="btn btn-custom">Get Started</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
