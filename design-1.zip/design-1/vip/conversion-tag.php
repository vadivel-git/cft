<section class="vd-black">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                </div>
            </div>
            <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
            </div>
        </div>
    </div>
</section>