<?php include'vip/doctype.php';?>
  <title>Online Services</title>
  <meta name="description" content="Responsive bootstrap landing template">
  <meta name="author" content="Coderthemes">
  <?php include'vip/link-css.php';?>
  </head>

    <body>
      <?php include'vip/header.php';?>
        <section class="section-lg home-alt bg-img-3" id="home">
          <div class="bg-overlay1"></div>
          <div class="container">
            <div class="row">
              <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                  <h1>Clients & Testimonials</h1> </div>
              </div>
            </div>
          </div>
        </section>
        <?php include'vip/number-tag.php';?>
          <section class="section" id="clients">
            <div class="container">
              <div class="row text-center">
                <div class="col-sm-12">
                  <div class="carousel-wrap">
                    <div class="owl-carousel">
                      <div class="item"><img src="http://vanandesk.com/img/client1.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client2.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client3.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client4.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client5.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client6.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client7.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client8.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client9.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client10.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client11.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client12.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client13.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client14.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client15.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client16.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client17.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client18.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client19.png" alt="clients"></div>
                      <div class="item"><img src="http://vanandesk.com/img/client20.png" alt="clients"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section class="section bg-white">
            <div class="container">
              <div class="row">
                <div class="col-md-4 col-sm-6 team">
                  <div class="panel-body vd-panel">
                    <div class="team-image"> <img src="img/testi-1.jpg" alt="onlineservices" class="img-responsive"> </div>
                    <div class="team-title">
                      <h4 class="color-1">Jeremy Piven</h4>
                      <div class="sub-title">Lead Designer</div>
                    </div>
                    <hr>
                    <p>Jeremy is possibly the best designer in the world. His designs make your content sing and your ideas zing. But don’t take our word for it, take his.</p>
                  </div>
                </div>
                <div class="col-md-4 col-sm-6 team">
                  <div class="panel-body vd-panel">
                    <div class="team-image"> <img src="img/testi-1.jpg" alt="onlineservices" class="img-responsive"> </div>
                    <div class="team-title">
                      <h4 class="color-1">Jeremy Piven</h4>
                      <div class="sub-title">Lead Designer</div>
                    </div>
                    <hr>
                    <p>Jeremy is possibly the best designer in the world. His designs make your content sing and your ideas zing. But don’t take our word for it, take his.</p>
                  </div>
                </div>
                <div class="col-md-4 col-sm-6 team">
                  <div class="panel-body vd-panel">
                    <div class="team-image"> <img src="img/testi-1.jpg" alt="onlineservices" class="img-responsive"> </div>
                    <div class="team-title">
                      <h4 class="color-1">Jeremy Piven</h4>
                      <div class="sub-title">Lead Designer</div>
                    </div>
                    <hr>
                    <p>Jeremy is possibly the best designer in the world. His designs make your content sing and your ideas zing. But don’t take our word for it, take his.</p>
                  </div>
                </div>
                <div class="col-md-4 col-sm-6 team">
                  <div class="panel-body vd-panel">
                    <div class="team-image"> <img src="img/testi-1.jpg" alt="onlineservices" class="img-responsive"> </div>
                    <div class="team-title">
                      <h4 class="color-1">Jeremy Piven</h4>
                      <div class="sub-title">Lead Designer</div>
                    </div>
                    <hr>
                    <p>Jeremy is possibly the best designer in the world. His designs make your content sing and your ideas zing. But don’t take our word for it, take his.</p>
                  </div>
                </div>
                <div class="col-md-4 col-sm-6 team">
                  <div class="panel-body vd-panel">
                    <div class="team-image"> <img src="img/testi-1.jpg" alt="onlineservices" class="img-responsive"> </div>
                    <div class="team-title">
                      <h4 class="color-1">Jeremy Piven</h4>
                      <div class="sub-title">Lead Designer</div>
                    </div>
                    <hr>
                    <p>Jeremy is possibly the best designer in the world. His designs make your content sing and your ideas zing. But don’t take our word for it, take his.</p>
                  </div>
                </div>
                <div class="col-md-4 col-sm-6 team">
                  <div class="panel-body vd-panel">
                    <div class="team-image"> <img src="img/testi-1.jpg" alt="onlineservices" class="img-responsive"> </div>
                    <div class="team-title">
                      <h4 class="color-1">Jeremy Piven</h4>
                      <div class="sub-title">Lead Designer</div>
                    </div>
                    <hr>
                    <p>Jeremy is possibly the best designer in the world. His designs make your content sing and your ideas zing. But don’t take our word for it, take his.</p>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
          </section>
          <?php include'vip/footer.php';?>
            <?php include'vip/common-js.php';?>
              <script src="js/common-script.js"></script>

    </body>

    </html>
