<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>

</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-4" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>We have all the answers for your queries!</h1> </div>
            </div>
        </div>
    </div>
</section>

       <?php include'vip/number-tag.php';?>

 <section class="section" id="faqs">
            <div class="container">
<div class="text-center vd-form-tit">60,000+ customers across the globe entrust in us</div>
              <div class="row col-txt100">
            <div class="col-lg-12">
               <div class="tabbable-line">
                <div role="tabbable-panel margin-tops4 ">
                   <ul class="nav nav-tabs tabtop  tabsetting">
                            <li class="active"> <a href="#description" data-toggle="tab">Upload</a> </li>
                            <li> <a href="#info" data-toggle="tab">Dropbox</a> </li>
                            <li> <a href="#messages" data-toggle="tab">Email ID</a> </li>
                        </ul>


                    <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="description">
                        <iframe src="https://www.hightail.com/u/VananTranscription" marginheight="0" marginwidth="0" style="overflow-x: hiiden; width: 100%; height: 700px; position:relative; border:none;" class="as-btn-shadow" scrolling="hidden auto" frameborder="1"></iframe>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="info">
                    <div class="vd-para">
                    Make a Dropbox account and share or send the link with <span class="text-colored">support@vananservices.com</span>
                    </div></div>
                    <div role="tabpanel" class="tab-pane" id="messages">
                    <div class="vd-para">
                    You can also attach your file and send to us through our email address <span class="text-colored">[support@vananservices.com]</span>. For inquiries, feel free to contact our support agent through toll free numbers or online chat. To know our work process, go to How it works page.</div></div>
                    </div>
                </div>
                </div>
            </div>
        </div>
            </div>
        </section>








<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

    </body>
</html>
