<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>


</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-2" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>Transcription Rates</h1> </div>
            </div>
        </div>
    </div>
</section>

<?php include'vip/number-tag.php';?>

<section class="section bg-white" id="clients">
    <div class="container">
        <div class="row text-center">
            <div class="col-sm-12">
                <h2 class="title">Transcription Rates</h2>
                <table id="acrylic">
                    <tbody>
                        <tr>
                            <td>Flat Rate</td>
                            <td>$0.99/min</td>
                        </tr>
                        <tr>
                            <td>Transcription Done by Native Transcribers</td>
                            <td>$1.25/min</td>
                        </tr>
                        <tr>
                            <td>Bulk Orders (10 to 20 hours)</td>
                            <td>Can be delivered within 24 to 48 hours, rush fee applies accordingly</td>
                        </tr>
                        <tr>
                            <td>Rush Turnaround Time</td>
                            <td>Deliver from 2 hours onwards <br><span class="vd-red">Note:</span> Rates vary based on the urgency and number of speakers</td>
                        </tr>
                    </tbody>
                </table>


            </div>
            <div class="col-sm-12">
                <h2 class="title">Language Transcription Rates</h2>
                <table id="acrylic">
                    <tbody>
                        <tr>
                            <td>Source To Source Language</td>
                            <td>$5/min</td>
                        </tr>
                        <tr>
                            <td>Source to Target Language</td>
                            <td>$7/min</td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php include'vip/conversion-tag.php';?>

<section class="section bg-white" id="clients">
    <div class="container">
        <div class="row text-center">
<div class="col-sm-12">
                <h2 class="title">Flexible Turnaround Time</h2>
                <table id="acrylic">
                  <thead>
                    <tr>
                      <th>File Length</th>
                      <th>Turnaround Time</th>
                    </tr>
                  </thead>
                    <tbody>
                        <tr>
                            <td>up to 30 min</td>
                            <td>12 Hours</td>
                        </tr>
                        <tr>
                            <td>up to 1 hour</td>
                            <td>24 Hours</td>
                        </tr>
                        <tr>
                            <td>up to 2 hours</td>
                            <td>2 to 3 Business Days</td>
                        </tr>
                        <tr>
                            <td>up to 3 hours</td>
                            <td>3 to 4 Business Days</td>
                        </tr>
                        <tr>
                            <td>up to 4 hours</td>
                            <td>4 to 5 Business Days</td>
                        </tr>
                        <tr>
                            <td>Files over 4 hours</td>
                            <td>For details chat with us now or call our toll free numbers</td>
                        </tr>
                      </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<section class="bg-white" id="clients">
  <div class="container">
    <div class="row text-center">
      <div class="col-sm-6">
        <h2 class="title">Added Value Services</h2>
        <table id="acrylic">
          <thead>
            <tr>
              <th>Additional Services</th>
              <th>Rates</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Verbatim</td>
              <td>$0.25/min</td>
            </tr>
            <tr>
              <td>Time stamping / Time coding</td>
              <td>$0.25/min</td>
            </tr>
            <tr>
              <td>up to 2 hours</td>
              <td>2 to 3 Business Days</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="col-sm-6">
        <h2 class="title">Complementary Services</h2>
        <table id="acrylic">
          <tbody>
            <tr>
              <td>Speaker Identification</td>
              <td><span class="vd-red">Free Note:</span> (Limited only to 5 speakers)</td>
            </tr>
            <tr>
              <td>File Type</td>
              <td>AIFF/AIF, MOV,CD, MP2, WMV,DDS, AMR, CAF, DVF, DVD, FLV, AVI, M4A, MSV, WMA and many other.</td>
            </tr>
            <tr>
              <td>Length of the audio</td>
              <td>Unlimited</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

    </body>
</html>
