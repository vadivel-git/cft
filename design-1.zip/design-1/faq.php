<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>

</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-4" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>We have all the answers for your queries!</h1> </div>
            </div>
        </div>
    </div>
</section>

       <?php include'vip/number-tag.php';?>

 <section class="section" id="faqs">
            <div class="container">
                <div class="row text-left">
                    <div class="col-sm-12">
                        <h2 class="title">Specific Information</h2>
                        <div class="row text-left">
                            <div class="col-sm-6">
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>What is Lorem Ipsum?</h4>
                                    <p><span><b>A. </b></span>Lorem ipsum dolor sit amet, in mea nonumes dissentias dissentiunt, pro te solet oratio iriure. Cu sit consetetur moderatius intellegam, ius decore accusamus te. Ne primis suavitate disputando nam. Mutat convenirete.</p>
                                </div>

                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>How many variations exist?</h4>
                                    <p><span><b>A. </b></span>Lorem ipsum dolor sit amet, in mea nonumes dissentias dissentiunt, pro te solet oratio iriure. Cu sit consetetur moderatius intellegam, ius decore accusamus te. Ne primis suavitate disputando nam. Mutat convenirete.</p>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>Is safe use Lorem Ipsum?</h4>
                                    <p><span><b>A. </b></span>Lorem ipsum dolor sit amet, in mea nonumes dissentias dissentiunt, pro te solet oratio iriure. Cu sit consetetur moderatius intellegam, ius decore accusamus te. Ne primis suavitate disputando nam. Mutat convenirete.</p>
                                </div>

                                <div class="question-box">
                                    <h4><span class="text-colored">Q.</span>License & Copyright</h4>
                                    <p><span><b>A. </b></span>Lorem ipsum dolor sit amet, in mea nonumes dissentias dissentiunt, pro te solet oratio iriure. Cu sit consetetur moderatius intellegam, ius decore accusamus te. Ne primis suavitate disputando nam. Mutat convenirete.</p>
                                </div>
                            </div>

                        </div>
                    </div> <!-- end Col -->
                </div>
               <div class="row text-left">
                    <div class="col-sm-12">
                        <h2 class="title">Services Information</h2>
                        <div class="row text-left">
<div class="col-sm-8">

  <div class="accordion_container">
    <div class="accordion_head"><span class="text-colored">Q.</span> What are the different ways I can contact for translation?<span class="plusminus">+</span></div>
    <div class="accordion_body" style="display: none;">
      <h4 class="vd-head">How many variations exist?</h4>
      <p class="text-muted vd-para"><span class="text-colored">A.</span>Lorem ipsum dolor sit amet, in mea nonumes dissentias dissentiunt, pro te solet oratio iriure. Cu sit consetetur moderatius intellegam, ius decore accusamus te. Ne primis suavitate disputando nam. Mutat convenirete.</p>
    </div>
  </div>

</div>

                        </div>
                    </div> <!-- end Col -->
                </div>
            </div>
        </section>



<section class="vd-black">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                </div>
            </div>
            <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
            </div>
        </div>
    </div>
</section>





 <?php include'vip/testimonial-tag.php';?>


 <?php include'vip/client-tag.php';?>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>
<script src="js/owl.carousel.min.js"></script>

<script>
      // JavaScript Document
$(document).ready(function () {
    //toggle the component with class accordion_body
    $(".accordion_head").click(function () {

        if ($('.accordion_body').is(':visible')) {
            $(".accordion_body").slideUp(300);
            $(".plusminus").text('+');
        }
        if ($(this).next(".accordion_body").is(':visible')) {
            $(this).next(".accordion_body").slideUp(300);
            $(this).children(".plusminus").text('+');
        } else {
            $(this).next(".accordion_body").slideDown(300);
            $(this).children(".plusminus").text('-');
        }
    });
})
</script>

    </body>
</html>
