$('#feedsubmit').click(function(){
    var fname = $('#fname').val();
    var femail=$('#femail').val();
    var ffeedback=$('#ffeedback').val();
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress = femail;  

    if(fname!='' && femail!='' && reg.test(eaddress) != false)
    { 
    	$('#msg').css({'color':'#F00'});	
		$('#msg').html('Select Script !');	
        $.ajax({  
        url:'php/feedback-db.php',
        data: "fname="+fname+"&femail="+femail+"&ffeedback="+ffeedback,                         
        type: 'POST',
  
        success: function(data){
            //alert("hi");
            $('#msg').css({'color':'#F00'});	
            $('#msg').html(data);
            $('#fname').val('');
            $('#femail').val('');
            $('#feedback').val('');
          

        },
      error : function(data) {
       
      }   
      });
    }
    else
    {
    if(fname=='')
        {
            $('#fname').tooltip({title: "Enter Name !"}); 
            $('#fname').focus();
            $('#fname').keypress(function() {
                $('#fname').tooltip('destroy');
            });    
            return false;
        }
    else if(femail=='')
        {
            $('#femail').tooltip({title: "Enter Email ID !"}); 
            $('#femail').focus();
            $('#femail').keypress(function() {
                $('#femail').tooltip('destroy');
            });
            return false;   
        }
    else if(reg.test(eaddress) == false)
        { 
            $('#femail').tooltip({title: "Enter Valid Email ID !"}); 
            $('#femail').focus();
            $('#email').keypress(function() {
                $('#femail').tooltip('destroy');
            });   
            return false;
        }

    }
}); 
