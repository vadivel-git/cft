

//sticky header on scroll
            $(window).load(function() {
                $(".sticky").sticky({topSpacing: 0});
            });


//animation banner letter
$(function(e) {
            "use strict";

            $(".tlt").textillate({
                loop: true,
                minDisplayTime: 2e3,
                initialDelay: 0,
                autoStart: true,
                "in": {
                    effect: "flipInY",
                    delayScale: 2.5,
                    delay: 30,
                    sync: false,
                    shuffle: false,
                    reverse: false
                },
                out: {
                    effect: "flipOutY",
                    delayScale: 2.5,
                    delay: 10,
                    sync: false,
                    shuffle: false,
                    reverse: false
                }
            })
        });


//clients auto play
    $('.owl-carousel').owlCarousel({
  loop: true,
  margin: 10,
  nav: true,
  navText: [
    "<i class='fa fa-caret-left'></i>",
    "<i class='fa fa-caret-right'></i>"
  ],
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1
    },
    600: {
      items: 3
    },
    1000: {
      items: 5
    }
  }
})


/* ==============================================
Magnific Popup
=============================================== */
$(document).ready(function () {
  $('.popup-video').magnificPopup({
    disableOn: 700
    , type: 'iframe'
    , mainClass: 'mfp-fade'
    , removalDelay: 160
    , preloader: false
    , fixedContentPos: false
  });
});


//    <!-- chat option -->

var __lc={};__lc.license=3112802,function(){var t=document.createElement("script");t.type="text/javascript",t.async=!0,t.src=("https:"==document.location.protocol?"https://":"http://")+"cdn.livechatinc.com/tracking.js";var e=document.getElementsByTagName("script")[0];e.parentNode.insertBefore(t,e)}();



//tooltip
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="tooltip"]').on('shown.bs.tooltip', function () {
        $('.tooltip').addClass('animated false');
    })
})


//bookmark

function addBookmark() {
  if (window.sidebar) {
    window.sidebar.addPanel(location.href, document.title, "")
  } else {
    if (document.all) {
      window.external.AddFavorite(location.href, document.title)
    } else {
      if (window.opera && window.print) {
        alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")
      } else {
        if (window.chrome) {
          alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")
        } else {
          alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")
        }
      }
    }
  }
};


/*back to top*/
$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });

        $('#back-to-top').tooltip('hide');

});

