<?php include'vip/doctype.php';?>

<title>Online Services</title>
<meta name="description" content="Responsive bootstrap landing template">
<meta name="author" content="Coderthemes">

<?php include'vip/link-css.php';?>


</head>


    <body>
       <?php include'vip/header.php';?>

<section class="section-lg home-alt bg-img-5" id="home">
    <div class="bg-overlay1"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                    <h1>Special Offers</h1> </div>
            </div>
        </div>
    </div>
</section>

       <?php include'vip/number-tag.php';?>

<section class="section">
<div class="container">

<!--block 1-->
<div class="row text-left">
<div class="col-md-8">
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-list icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Lifetime Offers</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diploma icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Bulk Order Offer</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-internet icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Free Trial Offer</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diamond icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Enterprise Accounts</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
</div>
<div class="col-md-4 margin-tops5">
  <img src="img/offer.jpg" alt="special offers" class="img-responsive vd-offer-img">
</div>
</div>
<!--block 1-->

<!--block 2-->
</div>
</section>

<section class="section bg-white">
<div class="container">

<!--block 1-->
<div class="row text-left">
<div class="col-md-4 margin-tops5">
  <img src="img/offer1.jpg" alt="special offers" class="img-responsive vd-offer-img">
</div>
<div class="col-md-8">
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-list icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Academic Lifetime Offers</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diploma icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Platinum Customer Benefits</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-internet icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Offer For Government Agencies</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 vd-pad40">
    <div class="col-xs-2"><span class="icon-diamond icon-fa text-colored" data-selector="span.fa"></span></div>
    <div class="col-xs-10">
        <div class="editContent">
            <h4>Seasonal Offers</h4> </div>
        <div class="editContent">
            <p>Retro chillwave YOLO four loko photo booth. Brooklyn kale chips, seitan hella 3 wolf moon slow-carb paleo.</p>
        </div>
    </div>
</div>
</div>
</div>
<!--block 1-->

<!--block 2-->
</div>
</section>



<section class="vd-black">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-9 col-lg-10 mp-dis-table">
                <div class="mp-text-vertical-center">
                    <p class="text-white mp-conversion">Get an Instant free quote tailored exclusively for you!</p>
                </div>
            </div>
            <div class="col-xs-9 col-sm-3 col-lg-2 mp-dis-table">
                <div class="mp-text-vertical-center"> <a href="#" class="vd-bbtn">Get In Touch</a> </div>
            </div>
        </div>
    </div>
</section>





 <?php include'vip/testimonial-tag.php';?>


 <?php include'vip/client-tag.php';?>

<?php include'vip/footer.php';?>

<?php include'vip/common-js.php';?>

<script src="js/common-script.js"></script>

    </body>
</html>
