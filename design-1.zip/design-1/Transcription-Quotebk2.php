<?php include'vip/doctype.php';?>
  <title>Online Services</title>
  <meta name="description" content="Responsive bootstrap landing template">
  <meta name="author" content="Coderthemes">
  <?php include'vip/link-css.php';?>

    <body>
      <?php include'vip/header.php';?>
        <section class="section-lg home-alt bg-img-4" id="home">
          <div class="bg-overlay1"></div>
          <div class="container">
            <div class="row">
              <div class="col-sm-12 text-center">
                <div class="home-wrapper">
                  <h1>We have all the answers for your queries!</h1> </div>
              </div>
            </div>
          </div>
        </section>
        <?php include'vip/number-tag.php';?>
<section class="section" id="faqs">
  <div class="container">
    <div id="form_box" class="center-block">
      <?php
  $redirect_file_content = '';
  echo $redirect_file_content = file_get_contents('http://vananhost.com/vanancrm/get-quote-form.php?service_type=transcription');
  $CRMFORM ="1";
?>
    </div>
  </div>
</section>

              <?php include'vip/footer.php';?>
                <?php include'vip/common-js.php';?>
                  <script src="js/common-script.js"></script>

    </body>

    </html>
