<?php include'vip/doctype.php';?>
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Vadivel-design-2</title>
  <?php include'vip/css-links.php';?>
    </head>

    <body data-spy="scroll" data-target="#data-scroll">

      <?php include'vip/header.php';?>
        <!-- HOME -->
        <section class="home bg-home" id="home">
          <div class="bg-overlay"></div>
          <div class="container">
            <div class="row">
              <div class="col-sm-12">
                <div class="home-fullscreen">
                  <div class="full-screen">
                    <div class="home-wrapper home-wrapper-alt">
                      <div class="row">
                        <div class="col-sm-6">
                          <h1>60,000+ <br/> Satisfied Clients & Counting!</h1>
                          <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat arcu ut orci porta, eget porttitor felis suscipit. Sed a nisl ullamcorper, tempus augue at, rutrum lacus. Duis et turpis eros.</h4> <a href="" class="btn btn-custom">Get Started</a>
                          <a href="https://vimeo.com/175710248" class="video-btn btn popup-video"><img src="img/play-symbol.png" alt=""> Watch Video</a>
                        </div>
                        <div class="col-sm-6">
                          <div class="col-sm-10 center-page text-center">
                            <div class="block">
                              <div class="vd-counter">
                                <ul class="vd-countdown">
                                  <li>
                                    <div class="dash days_dash">
                                      <div class="digit"> <img src="img/clock.png" alt="gift">
                                        <p class="vd-count-p">Turnaround from 12 hrs</p>
                                      </div>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="dash days_dash">
                                      <div class="digit"> <img src="img/article.png" alt="gift">
                                        <p class="vd-count-p">800+ Native Transcribers</p>
                                      </div>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="dash days_dash">
                                      <div class="digit"> <img src="img/iso.png" alt="gift">
                                        <p class="vd-count-p">ISO Certified 9001:2008</p>
                                      </div>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="dash days_dash">
                                      <div class="digit"> <img src="img/lock.png" alt="gift">
                                        <p class="vd-count-p">Secure &amp; Confidential</p>
                                      </div>
                                    </div>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- end container -->
          <div class="vv-clearfix"></div>
          <div id="to-slider-scrollto"> <a href="#service"><i class="fa fa-angle-double-down icon-option"></i></a> </div>
        </section>
        <!-- END HOME -->
        <section class="section" id="service">
          <div class="container">
            <div class="vv-ser-block">
              <div class="row">
                <div class="col-sm-4">
                  <h2 class="txt-left">We Are
      <br> <strong><span style="color:#ff6863">Transcription</span></strong> </h2>
                  <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna estasente et. Quisque euismod orci ut et lobortis aliquam.</p>
                </div>
                <div class="col-sm-4"> <img src="img/audio.png" alt="services" class="vv-img-1">
                  <div class="vv-title">Audio Transcription</div>
                  <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna estasente et. Quisque euismod orci ut et lobortis aliquam.</p>
                </div>
                <div class="col-sm-4"> <img src="img/video.png" alt="services" class="vv-img-1" width="55">
                  <div class="vv-title">Video Transcription</div>
                  <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna estasente et. Quisque euismod orci ut et lobortis aliquam.</p>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-4"> <img src="img/legal.png" alt="services" class="vv-img-1">
                  <div class="vv-title">Legal Transcription</div>
                  <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna estasente et. Quisque euismod orci ut et lobortis aliquam.</p>
                </div>
                <div class="col-sm-4"> <img src="img/academic.png" alt="services" class="vv-img-1">
                  <div class="vv-title">Academic Transcription</div>
                  <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna estasente et. Quisque euismod orci ut et lobortis aliquam.</p>
                </div>
                <div class="col-sm-4"> <img src="img/business.png" alt="services" class="vv-img-1">
                  <div class="vv-title">Business Transcription</div>
                  <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna estasente et. Quisque euismod orci ut et lobortis aliquam.</p>
                </div>
              </div>

         </div>
          </div>
        </section>
        <section class="section vv-about-block">
          <div class="container" style="display: table;">
            <div class="row">
              <div class="col-sm-12 vv-table-text text-center"> <span class="vv-ctc-block">Welcome To Vanan Group Of Companies</span>
                <div class="col-sm-8 center-page">
                  <p class="vv-ctc-ab">With solid years of experience, and thousands of successful projects on our books, we continue to serve our clients with ironclad commitment and passion.</p>
                  <div class="col-sm-12 vv-pt-1 text-center"> <a href="" class="btn btn-custom">About Us</a> </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="section">
          <div class="container">
            <div class="row">
              <h3 class="vv-title1 text-center">Our <span class="vv-tit-b">Process</span></h3>
              <div class="col-sm-10 center-page">
                <div class="vv-ser-block">
                  <div class="col-sm-4 text-center"> <img src="img/quote.png" alt="services" class="vv-img-1">
                    <div class="vv-title">Ask for a Quote</div>
                    <p class="vv-p-10"> Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                  </div>
                  <div class="col-sm-4 text-center"> <img src="img/mail.png" alt="services" class="vv-img-1">
                    <div class="vv-title">Confirm the Project</div>
                    <p class="vv-p-10"> Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                  </div>
                  <div class="col-sm-4 text-center"> <img src="img/check.png" alt="services" class="vv-img-1">
                    <div class="vv-title">Pay Online</div>
                    <p class="vv-p-10"> Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                  </div>
                  <div class="col-sm-12 vv-pt-1 text-center"> <a href="" class="btn btn-custom">Get Started</a> </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="vv-client-block">
          <div class="container-fluid" style="display: table;">
            <div class="row">
              <div class="col-sm-8 v-c-5">
                <div class="col-xs-4 col-sm-4">
                  <div class="vv-number-count">
                    <div class="vv-count-1"> <img src="img/count-client.png" alt="" width="40" class="pull-right vv-count-img1"> <span class="vv-c-1 counter">1024</span>
                      <div class="vv-c-2">Happy Clients</div>
                    </div>
                  </div>
                </div>
                <div class="col-xs-4 col-sm-4">
                  <div class="vv-number-count">
                    <div class="vv-count-1"> <img src="img/checked.png" alt="" width="40" class="pull-right vv-count-img1"> <span class="vv-c-1 counter">1024</span>
                      <div class="vv-c-2">Completed</div>
                    </div>
                  </div>
                </div>
                <div class="col-xs-4 col-sm-4">
                  <div class="vv-number-count">
                    <div class="vv-count-1"> <img src="img/download.png" alt="" width="40" class="pull-right vv-count-img1"> <span class="vv-c-1 counter">1024</span>
                      <div class="vv-c-2">Downloaded</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-4 v-c-5 v-c-6">
                <div class="vv-c-4">
                  <div class="vv-c-3">Features</div>
                  <p class="vv-c-7">Quisque porta ipsum quis neque elementum lacinia. Pellentesque ut risus rutrum, tristique lacus nec, mollis risus. Vestibulum mollis erat arcu, eu vehicula purus consequat nec nulla turpis leo, aliquet.</p> <a target="_self" class="vv-btn-light">Get Started</a> </div>
              </div>
            </div>
            <div class="row vv-client-bg">
              <div class="col-sm-4 v-c-5 v-c-6-plus">
                <div class="vv-c-4">
                  <div class="vv-c-3">Trusted Our Clients</div>
                  <p class="vv-c-7">Quisque porta ipsum quis neque elementum lacinia. Pellentesque ut risus rutrum, tristique lacus nec, mollis risus. Vestibulum mollis erat arcu, eu vehicula purus consequat nec nulla turpis leo, aliquet.</p> <a target="_self" class="vv-btn-light vv-btn-light1">Get Started</a> </div>
              </div>
              <div class="col-sm-8 v-c-5">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                  <!-- Wrapper for slides -->
                  <div class="carousel-inner">
                    <div class="item container"> <img class="col-md-2 col-sm-2 col-xs-6 mp-client img-responsive" src="img/client1.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client2.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client3.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client4.png" alt="..." data-pin-nopin="true"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client5.png" alt="..." data-pin-nopin="true"> </div>
                    <div class="item container active"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client6.png" alt="..." data-pin-nopin="true"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client7.png" alt="..." data-pin-nopin="true"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client8.png" alt="..." data-pin-nopin="true"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client9.png" alt="..." data-pin-nopin="true"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client10.png" alt="..." data-pin-nopin="true"> </div>
                    <div class="item container"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client11.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client12.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client13.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client14.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client15.png" alt="..."> </div>
                    <div class="item container"> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client16.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client17.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client18.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client19.png" alt="..."> <img class="col-md-2 col-sm-2 col-xs-2 mp-client img-responsive" src="img/client20.png" alt="..."> </div>
                  </div>
                  <div align="center" class="mp-angle">
                    <!-- Controls -->
                    <a class="left" href="#carousel-example-generic" data-slide="prev"> <span class="fa fa-angle-left mp-left"></span> </a>
                    <a class="right" href="#carousel-example-generic" data-slide="next"> <span class="fa fa-angle-right mp-left"></span> </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="margin-t-50">
          <div class="container">
            <div class="row">
              <h3 class="vv-title1 text-center">Our <span class="vv-tit-b">Testimonial</span></h3>

              <div class="col-sm-6 vv-map-bg" style="display: table;">
                <img src="img/member-1.png" alt="client" class="img-responsive left vv-member" width="300">
                <div class="vv-count-1"> <span class="vv-feel"><img src="img/telephone.png" alt="calling"> Feel To Call</span>
                  <ul class="vv-call">
                    <li class="vv-us-number">US : 1-888-535-5668</li>
                    <li class="vv-us-number">UK : +44-80-8238-0078</li>
                    <li class="vv-us-number">AUS : +61-1-8003-57380</li>
                  </ul>
                </div>
              </div>

              <div class="col-sm-6" style="display: table;">
                <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                  <!-- Bottom Carousel Indicators -->
                  <ol class="carousel-indicators">
                    <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
                    <li data-target="#quote-carousel" data-slide-to="1"></li>
                    <li data-target="#quote-carousel" data-slide-to="2"></li>
                  </ol>
                  <!-- Carousel Slides / Quotes -->
                  <div class="carousel-inner">
                    <!-- Quote 1 -->
                    <div class="item active">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center">
                            <img class="img-circle" src="img/profile-s-1.png" style="width: 100px;height:100px;">
                            <!--<img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/kolage/128.jpg" style="width: 100px;height:100px;">-->
                          </div>
                          <div class="col-sm-9">
                            <p class="vv-reviwe">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! adipisci velit! adipisci velit!.</p>
                            <small>Someone famous</small>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                    <!-- Quote 2 -->
                    <div class="item">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center">
                            <img class="img-circle" src="img/profile-s-2.png" style="width: 100px;height:100px;">
                          </div>
                          <div class="col-sm-9">
                            <p class="vv-reviwe">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! adipisci velit! adipisci velit!.</p>
                            <small>Someone famous</small>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                    <!-- Quote 3 -->
                    <div class="item">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center">
                            <img class="img-circle" src="img/profile-s-3.png" style="width: 100px;height:100px;">
                          </div>
                          <div class="col-sm-9">
                            <p class="vv-reviwe">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! adipisci velit! adipisci velit!.</p>
                            <small>Someone famous</small>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                  </div>
                </div>


              </div>


            </div>
          </div>
        </section>

        <?php include'vip/footer.php';?>
          <?php include'vip/common-scripts.php';?>
    </body>

    </html>
