<!-- Google Fonts -->
<link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Prompt:200,300,400,500,400i,700" rel="stylesheet">
<!-- logo only -->
<link href="https://fonts.googleapis.com/css?family=Mitr:500" rel="stylesheet">
<!-- Bootstrap CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Icon CSS -->
<link href="css/themify-icons.css" rel="stylesheet">
<!-- Owl Carousel CSS -->
<link href="css/owl.carousel.css" rel="stylesheet">
<link href="css/owl.theme.default.min.css" rel="stylesheet">
<!-- Magnific-popup -->
<link rel="stylesheet" href="css/magnific-popup.css">
<!-- Custom styles for this template -->
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<!--font awsomes icons-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

