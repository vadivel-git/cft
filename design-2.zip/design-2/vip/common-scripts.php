<!-- js placed at the end of the document so the pages load faster -->
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Sticky Header -->
<script src="js/jquery.sticky.js"></script>
<!-- Jquery easing -->
<script type="text/javascript" src="js/jquery.easing.1.3.min.js"></script>
<!-- Owl Carousel -->
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<!--Counter-->
<script src="js/waypoints.min.js" type="text/javascript"></script>
<!-- Magnific Popup -->
<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
<!-- Custom js -->
<script src="js/app.js"></script>

<script src="js/jquery.counterup.js"></script>

<!--jquery counter-->
 <script>
    jQuery(document).ready(function( $ ) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
  </script>

<script>
  jQuery(document).ready(function ($) {
  $('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    autoplay: true,
    autoplayTimeout: 4000,
    responsive: {
      0: {
        items: 1
      }
    }
  });

  $('.counter').counterUp({
    delay: 100,
    time: 1200
  });
});
</script>

<script>
/*back to top*/
$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });

});
</script>


<script>
// When the DOM is ready, run this function
$(document).ready(function() {
  //Set the carousel options
  $('#quote-carousel').carousel({
    pause: true,
    interval: 4000,
  });
});
</script>

