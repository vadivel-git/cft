<!-- Loader -->
      <div id="preloader"><div id="status"><div class="spinner">Loading...</div></div></div>
      <!-- Navbar -->
      <div class="navbar navbar-custom sticky" role="navigation">
        <div class="container">
          <!-- Navbar-header -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <i class="fa fa-bars"></i> </button>
            <!-- LOGO --><a class="navbar-brand logo" href="index.html">
                        Hour<span>trans</span>
                    </a> </div>
          <!-- end navbar-header -->
          <!-- menu -->
          <div class="navbar-collapse collapse" id="data-scroll">
            <ul class="nav navbar-nav navbar-right">
              <li> <a href="index.php">Home</a> </li>
              <li> <a href="inner.php">Services</a> </li>
              <li> <a href="#">Features</a> </li>
              <li> <a href="#">Team</a> </li>
              <li> <a href="#">Pricing</a> </li>
              <li> <a href="#">Blog</a> </li>
              <li> <a href="#">Contact</a> </li>
            </ul>
          </div>
          <!--/Menu -->
        </div>
        <!-- end container -->
      </div>
