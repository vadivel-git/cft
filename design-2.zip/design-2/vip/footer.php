<footer class="bg-dark footer">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-3">
        <h4 class="logo">Hour<span>trans</span></h4>
        <p class="vv-para">Architecto beatae vitae dicta sunt explicabo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vel sapien et lacus tempus varius. In finibus lorem vel.</p>

      </div>
      <div class="col-md-3 col-sm-3">
        <h5>Solutions</h5>
        <ul class="list-unstyled footer-list">
          <li><a href="">Web Design</a></li>
          <li><a href="">Graphic Design</a></li>
          <li><a href="">Power &amp; Energy</a></li>
          <li><a href="">Solar Power</a></li>
          <li><a href="">Green energy</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-3">
        <h5>Useful Links</h5>
        <ul class="list-unstyled footer-list">
          <li><a href="">About Us</a></li>
          <li><a href="">Help &amp; Support</a></li>
          <li><a href="">Privacy Policy</a></li>
          <li><a href="">Terms &amp; Conditions</a></li>
          <li><a href="">FAQ</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-3">
        <h5>Useful Links</h5>
        <img src="img/paypal.png" alt="pay pal">
<ul class="list-inline social">
<li><a href="javascript:void(0);" class="bg-facebook"><i class="fa fa-facebook"></i></a> </li>
<li><a href="javascript:void(0);" class="bg-twitter"> <i class="fa fa-twitter"></i></a></li>
<li><a href="javascript:void(0);" class="bg-googleplus"><i class="fa fa-google-plus"></i></a> </li>
</ul>
      </div>
    </div>

    <!-- end row -->
  </div>


  <div class="footer-one-alt">
            <div class="container">
              <div class="row">
                <div class="col-sm-5">
                  <p class="vv-copyright">© 2016 My Design. Design by Design</p>
                </div>
              </div>
            </div>
          </div>
  <!-- end container -->
</footer>
