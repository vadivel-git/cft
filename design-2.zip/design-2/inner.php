<?php include'vip/doctype.php';?>
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Vadivel-design-2</title>
  <?php include'vip/css-links.php';?>
    </head>

    <body data-spy="scroll" data-target="#data-scroll">
      <?php include'vip/header.php';?>
        <!-- HOME -->
        <section class="home bg-home" id="home">
          <div class="bg-overlay-inner"></div>
          <div class="container">
            <div class="row">
              <div class="col-sm-12">
                <div class="home-fullscreen vv-inner-fullscreen">
                  <div class="full-screen">
                    <div class="home-wrapper home-wrapper-alt">
                      <div class="row">
                        <div class="col-sm-10 center-page">
                          <div class="vv-inner-home text-center">
                            <h1>Transcription Services <span class="vd-colord">$0.99</span>/min</h1> <span class="vd-inner-lan">
<i class="fa fa-circle-o light-color" aria-hidden="true"></i>
Turnaround from <span class="vd-underline">24 hrs</span></span> <span class="vd-inner-lan">
<i class="fa fa-circle-o light-color" aria-hidden="true"></i>
<span class="vd-underline">800+</span> Native Transcribers </span> <span class="vd-inner-lan">
<i class="fa fa-circle-o light-color" aria-hidden="true"></i>
ISO Certified <span class="vd-underline">9001:2008</span> </span>
                            <div class="clearfix"></div>
                            <div class="col-sm-8 vd-center-form center-page">
                              <div class="vd-bgcolor">
                                <form action="#">
                                  <div class="vd-ask">Ask for a Quote Now!</div>
                                  <div class="row">
                                    <div class="col-sm-6">
                                      <div class="form-group vd-group">
                                        <input type="text" class="form-control" placeholder="Name" required="required"> </div>
                                    </div>
                                    <div class="col-sm-6">
                                      <div class="form-group vd-group">
                                        <input type="text" class="form-control" placeholder="Email Id" required="required"> </div>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-sm-6">
                                      <div class="form-group vd-group">
                                        <select class="form-control plain-select" id="ttype" data-placement="bottom">
                                          <option value="">Select</option>
                                          <option value="General">General</option>
                                          <option value="Legal">Legal</option>
                                        </select>
                                      </div>
                                    </div>
                                    <div class="col-sm-6">
                                      <div class="form-group vd-group">
                                        <input type="text" class="form-control" placeholder="Mintues" required="required"> </div>
                                    </div>
                                  </div>
                                </form>
                                <div class="clearfix"></div> <a href="#" class="btn btn-custom">Get Started</a> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- end container -->
          <div class="vv-clearfix"></div>
        </section>
        <!-- END HOME -->
        <section class="section bg-gray">
          <div class="container vv-top">
            <div class="row">
              <h3 class="vv-title1 text-center">Our <span class="vv-tit-b">Process</span></h3>
              <div class="col-sm-10 center-page">
                <div class="vv-ser-block">
                  <div class="col-sm-4 text-center"> <img src="img/quote.png" alt="services" class="vv-img-1">
                    <div class="vv-title">Ask for a Quote</div>
                    <p class="vv-p-10"> Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                  </div>
                  <div class="col-sm-4 text-center"> <img src="img/mail.png" alt="services" class="vv-img-1">
                    <div class="vv-title">Confirm the Project</div>
                    <p class="vv-p-10"> Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                  </div>
                  <div class="col-sm-4 text-center"> <img src="img/check.png" alt="services" class="vv-img-1">
                    <div class="vv-title">Pay Online</div>
                    <p class="vv-p-10"> Specify your details and get an instant quote! upload your files onto our servers and we will send you a confirmation mail.</p>
                  </div>
                  <div class="col-sm-12 vv-pt-1 text-center"> <a href="" class="btn btn-custom">Get Started</a> </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="section">
          <div class="container">
            <div class="row">
              <div class="col-sm-8">
                <h2 class="vv-title1">Transcription <span class="vv-tit-b">Services</span></h2>
                <p class="vv-p">Most companies today understand that an effective communication is essential to the success of any endeavors. This is why there is an increasing demand for online transcriptionist who can offer quality transcription services, Mississauga. As the sixth largest city in Canada, Mississauga is a business hub for a broad range of</p>
                <div class="panel with-nav-tabs vv-panel">
                  <div class="panel-heading">
                    <ul class="nav nav-tabs vv-tabs">
                      <li class="active"><a href="#tab1info" data-toggle="tab">Services</a></li>
                      <li><a href="#tab2info" data-toggle="tab">Features</a></li>
                      <li><a href="#tab3info" data-toggle="tab">Features</a></li>
                    </ul>
                  </div>
                  <div class="panel-body">
                    <div class="tab-content vv-tab-content">
                      <div class="tab-pane fade in active" id="tab1info">
                        <p class="vv-p">Most companies today understand that an effective communication is essential to the success of any endeavors. This is why there is an increasing demand for online transcriptionist who can offer quality transcription services, Mississauga. As the sixth largest city in Canada, Mississauga is a business hub for a broad range </p>
                        <p class="vv-p">Most companies today understand that an effective communication is essential to the success of any endeavors. This is why there is an increasing demand for online transcriptionist who can offer quality transcription services, Mississauga. As the sixth largest city in Canada, Mississauga is a business hub for a broad range </p>
                        <p class="vv-p">Most companies today understand that an effective communication is essential to the success of any endeavors. This is why there is an increasing demand for online transcriptionist who can offer quality transcription services, Mississauga. As the sixth largest city in Canada, Mississauga is a business hub for a broad range </p>
                      </div>
                      <div class="tab-pane fade" id="tab2info">
                        <p class="vv-p">✓ Supports all file types</p>
                        <p class="vv-p">✓ NDA agreement</p>
                        <p class="vv-p">✓ 800+ transcribers</p>
                        <p class="vv-p">✓ 100+ Languages</p>
                        <p class="vv-p">✓ 24/7 customer support available</p>
                        <p class="vv-p">✓ Rush and super rush services available</p>
                      </div>
                      <div class="tab-pane fade" id="tab3info">
                        <p class="vv-p">✓ Supports all file types</p>
                        <p class="vv-p">✓ NDA agreement</p>
                        <p class="vv-p">✓ 800+ transcribers</p>
                        <p class="vv-p">✓ 100+ Languages</p>
                        <p class="vv-p">✓ 24/7 customer support available</p>
                        <p class="vv-p">✓ Rush and super rush services available</p>
                      </div>
                    </div>
                  </div>
                </div>
                <h3 class="vv-title2">Cheap Transcription Company Near Mississauga</h3>
                <p class="vv-p">There are a plethora of choices when it comes to transcription companies near Mississauga. But if budget is your concern, you can always count on ABC to offer affordable transcription services. Set at an economical flat rate of $0.99/min, our transcription services, Mississauga is the cheapest in the market today.</p>
              </div>
              <div class="col-sm-4">
                <div class="col-sm-12 text-left vv-how-iii vv-right-rate">
                  <div class="col-sm-12"> <span class="vv-size24">Transcription Rates</span>
                    <table class="table vd-m-t-20 vv-table">
                      <thead>
                        <tr>
                          <th class="vv-tab">Specifications</th>
                          <th class="vv-tab">Rates &amp; Turnaround</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Flat Rate</td>
                          <td>$0.99/min</td>
                        </tr>
                        <tr>
                          <td>Normal Turnaround Time</td>
                          <td>Starts From 12 Hrs</td>
                        </tr>
                        <tr>
                          <td>Source to Source Language</td>
                          <td>$5/min</td>
                        </tr>
                        <tr>
                          <td>Source to Target Language</td>
                          <td>$7/min </td>
                        </tr>
                        <tr>
                          <td>File length upto 20 hours</td>
                          <td>$0.99/min </td>
                        </tr>
                        <tr>
                          <td>File length upto 50 hours</td>
                          <td>$0.89/min</td>
                        </tr>
                        <tr>
                          <td>File length above 50 hours</td>
                          <td>$0.79/min </td>
                        </tr>
                      </tbody>
                    </table>
                    <div class="center-page text-center"> <a href="#" class="btn btn-custom">Get Started</a> </div>
                  </div>
                </div>
                <div class="col-sm-12 text-left vv-how-iii vv-right-rate">
                  <div class="col-sm-12"> <span class="vv-size24">We Also Provide</span></div>
                  <ul class="vv-circle-list">
                    <li><span class="light-color">✓</span> 60,000+ Happy Customers</li>
                    <li><span class="light-color">✓</span> 1,000+ Native Translators</li>
                    <li><span class="light-color">✓</span> 100+ Supported Languages</li>
                    <li><span class="light-color">✓</span> 100% USCIS Acceptance</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="margin-t-50">
          <div class="container">
            <div class="row">
              <h3 class="vv-title1 text-center">Our <span class="vv-tit-b">Testimonial</span></h3>
              <div class="col-sm-6 vv-map-bg" style="display: table;"> <img src="img/member-1.png" alt="client" class="img-responsive left vv-member" width="300">
                <div class="vv-count-1"> <span class="vv-feel"><img src="img/telephone.png" alt="calling"> Feel To Call</span>
                  <ul class="vv-call">
                    <li class="vv-us-number">US : 1-888-535-5668</li>
                    <li class="vv-us-number">UK : +44-80-8238-0078</li>
                    <li class="vv-us-number">AUS : +61-1-8003-57380</li>
                  </ul>
                </div>
              </div>
              <div class="col-sm-6" style="display: table;">
                <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                  <!-- Bottom Carousel Indicators -->
                  <ol class="carousel-indicators">
                    <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
                    <li data-target="#quote-carousel" data-slide-to="1"></li>
                    <li data-target="#quote-carousel" data-slide-to="2"></li>
                  </ol>
                  <!-- Carousel Slides / Quotes -->
                  <div class="carousel-inner">
                    <!-- Quote 1 -->
                    <div class="item active">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center"> <img class="img-circle" src="img/profile-s-1.png" style="width: 100px;height:100px;">
                            <!--<img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/kolage/128.jpg" style="width: 100px;height:100px;">--></div>
                          <div class="col-sm-9">
                            <p class="vv-reviwe">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! adipisci velit! adipisci velit!.</p> <small>Someone famous</small> </div>
                        </div>
                      </blockquote>
                    </div>
                    <!-- Quote 2 -->
                    <div class="item">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center"> <img class="img-circle" src="img/profile-s-2.png" style="width: 100px;height:100px;"> </div>
                          <div class="col-sm-9">
                            <p class="vv-reviwe">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! adipisci velit! adipisci velit!.</p> <small>Someone famous</small> </div>
                        </div>
                      </blockquote>
                    </div>
                    <!-- Quote 3 -->
                    <div class="item">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center"> <img class="img-circle" src="img/profile-s-3.png" style="width: 100px;height:100px;"> </div>
                          <div class="col-sm-9">
                            <p class="vv-reviwe">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! adipisci velit! adipisci velit!.</p> <small>Someone famous</small> </div>
                        </div>
                      </blockquote>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <?php include'vip/footer.php';?>
          <?php include'vip/common-scripts.php';?>
    </body>

    </html>
